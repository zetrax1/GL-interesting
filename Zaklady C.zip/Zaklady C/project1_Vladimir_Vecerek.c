// Projek 1 - proceduralne programovanie
// Letn� semester 2017
// vypracoval : Vladim�r Ve�erek



#include<stdio.h>
#include<stdlib.h>
#include <string.h>



int v_vypis_zaznamu(FILE **fr)
{

     char c;
     int pocet,cislo_ulice,datum;
     float dan;

     if((*fr=fopen("dan.txt","r"))==NULL) {
          printf("Neotvoreny subor");
          return 0;
     }
     while((c=getc(*fr))!=EOF) {
          printf("meno a priezvisko: %c",c);

          while((c=getc(*fr))!='\n') {
               printf("%c",c);
          }
          printf("\n");
          printf("ulica cislo: ");
          while((c=getc(*fr))!='\n') {
               printf("%c",c);
          }
          printf("\n");
          fscanf(*fr,"%f",&dan);
          c=getc(*fr);
          printf("dan: %.2f\n",dan);
          fscanf(*fr,"%d",&datum);
          printf("datum: %d\n",datum);
          c=getc(*fr);
          printf("%c",c);
     }

     return 1;
}


void d_najvyzsia_dan(FILE **fr)
{
     char ulica[52],aktualna_ulica[52],c;
     int i=0,cislo_ulice,tmp,datum,max_datum,a;
     float dan=0,najvyzsia_dan=0;


     c=getchar();
     c='a';
     while(c != '\n') {
          c=getchar();
          ulica[i]=c;

          i++;

     }
     ulica[i-1]='\0';

// AK PREDPOKLADAME ZE DAN MOZE BYT ZAPORNA
//     while((c=fgetc(*fr))!='\n') {};
//     c=getc(*fr);
//     i=0;
//     while(c!='\n') {
//          aktualna_ulica[i]=c;
//          c=getc(*fr);
//          i++;
//     }
//     aktualna_ulica[i-1]='\0';
//			tmp=1;
//          a=0;
//          while(ulica[a]!='\0') {
//               if(ulica[a]!=aktualna_ulica[a]) {
//                    tmp=0;
//               }
//               a++;
//          }
//
//     fscanf(*fr,"%f",&dan);
//     c=getc(*fr);
//     fscanf(*fr,"%d",&datum);
//     max_datum=(datum%10000);
//     najvyzsia_dan=dan;

     rewind(*fr);
     najvyzsia_dan=0;

     while((c=getc(*fr))!=EOF) {

          while((c=fgetc(*fr))!='\n') {};
          c=getc(*fr);
          i=0;
          while(c!='\n') {
               aktualna_ulica[i]=c;
               c=getc(*fr);
               i++;
          }
          aktualna_ulica[i]='\0';
          fscanf(*fr,"%f",&dan);
          c=getc(*fr);
          fscanf(*fr,"%d",&datum);

          c=getc(*fr);
          if((datum%10000)>=max_datum ) {
               max_datum= datum%10000;

          }

          tmp=1;
          a=0;
          while(ulica[a]!='\0') {
               if(ulica[a]!=aktualna_ulica[a]) {
                    tmp=0;
               }
               a++;
          }


          if(max_datum==(datum%10000) && tmp==1 && najvyzsia_dan<dan ) {
               najvyzsia_dan=dan;
          }

     }
     if(najvyzsia_dan!=0) {

          printf("%.2f\n",najvyzsia_dan);
     }
     return ;

}



int n_vytvorenie_pola(FILE **fr,int vytvorene,int *mnozstvo,int *max_dlzka,char ***pole)
{






     int i,datum,k=0,pocet=0;
     float dan;
     char c,aktualna_ulica[52];
     rewind(*fr);

     while((c=getc(*fr))!=EOF) {

          while((c=fgetc(*fr))!='\n') {};
          c=getc(*fr);
          i=0;
          while(c!='\n') {
               aktualna_ulica[i]=c;
               c=getc(*fr);
               i++;
          }
          aktualna_ulica[i]='\0';
          fscanf(*fr,"%f",&dan);
          c=getc(*fr);
          fscanf(*fr,"%d",&datum);
          c=getc(*fr);
          pocet++;
     }


     int j=0;


     if(vytvorene!=0) {
          int x;
          for(x=0; x<pocet; x++) {
               free((*pole)[x]);

          }
          free(*pole);
     }


     *mnozstvo =pocet;
     *pole = (char **) malloc((pocet) * sizeof(char *));


     rewind(*fr);
     while((c=getc(*fr))!=EOF) {

          while((c=fgetc(*fr))!='\n') {};
          c=getc(*fr);
          i=0;
          while(c!='\n') {
               aktualna_ulica[i]=c;
               c=getc(*fr);
               i++;
          }
          aktualna_ulica[i]='\0';
          if((*max_dlzka)<(strlen(aktualna_ulica))) {
               *max_dlzka=strlen(aktualna_ulica);
          }

          (*pole)[j]= (char *) malloc((strlen(aktualna_ulica)+1) * sizeof(char));
          k=0;

          while(aktualna_ulica[k]!='\0') {
               (*pole)[j][k]=aktualna_ulica[k];

               k++;
          }
          (*pole)[j][k]='\0';

          fscanf(*fr,"%f",&dan);
          c=getc(*fr);
          fscanf(*fr,"%d",&datum);
          c=getc(*fr);
          j++;
     }


     return 1;
}


void r_vypis_pola(char **pole,int mnozstvo,int max_dlzka)
{


     int i,j,dlzka_slova;
     for(i=0; i<mnozstvo; i++) {
          dlzka_slova=0;
          j=0;
          while(pole[i][j]!='\0') {
               dlzka_slova++;
               j++;
          }
          j=0;
          while(j<max_dlzka-dlzka_slova) {
               printf(" ");
               j++;
          }
          j=0;
          while(pole[i][j]!='\0') {
               printf("%c",pole[i][j]);
               j++;
          }
          printf("\n");
     }


}

void h_hystagram(char **pole,int mnozstvo)
{

     int i,j,k,l;
     for(i=0; i<=mnozstvo; i++) {
          char m='0';
          for(j=0; j<=9; j++) {

               if(i==0) {
                    printf("---%d",j);
               } else {
                    k=0;
                    l=0;

                    while(pole[i-1][k]!='\0') {


                         if(pole[i-1][k]==m) {
                              l++;
                         }
                         k++;

                    }
                    if(l>9) {
                         printf("  %d",l);
                    } else {
                         printf("   %d",l);
                    }
                    m=m+1;

               }

          }
          printf("\n");
     }

}



void precitaj_ulicu()
{
     char c;

     c=getchar();
     c='a';
     while(c != '\n') {
          c=getchar();
     }

}



char** p_funkcia_pridaj(char ***pole,int *mnozstvo)
{


     char **tmppole,c,ulica[52];
     int pozicia,i=0,pocet,j,k,aktualna_ul;

     c=getchar();
     scanf("%d",&pozicia);
     c=getchar();
     c='a';
     while(c != '\n') {
          c=getchar();
          ulica[i]=c;

          i++;

     }
     ulica[i-1]='\0';

     pocet=(*mnozstvo)+1;
     if(pocet<pozicia) {
          return;
     }



     tmppole = (char **) malloc((pocet) * sizeof(char *));
     int	a=0;
     for(j=0; j<pocet-2; j++) {

          k=0;
          if(j==pozicia) {
               (tmppole)[j]= (char *) malloc((strlen(ulica)+1) * sizeof(char));
               while(ulica[k]!='\0') {
                    tmppole[j][k]=ulica[k];

                    k++;
               }
               tmppole[j][k]='\0';
               j++;

          }
          k=0;
          aktualna_ul=0;

          while((*pole)[a][k]!='\0') {
               aktualna_ul++;
               k++;
          }
          (tmppole)[j]= (char *) malloc((aktualna_ul+1) * sizeof(char));
          k=0;
          while((*pole)[a][k]!='\0') {
               tmppole[j][k]=(*pole)[a][k];
               k++;
          }
          (tmppole)[j][k]='\0';
          a++;
     }



     int x;
     for(x=0; x<pocet-1; x++) {
          free((*pole)[x]);

     }
     free(*pole);





     return tmppole;

}



void x_histagram2(char **pole,int mnozstvo)
{

     int delitel,i,j=0,k=0,tmp;
     scanf("%d",&delitel);
     char m='9';
     for(i=9; i>=0; i--) {
		
          tmp=0;
          while(j<mnozstvo) {
				
               k=0;
               
               while(pole[j][k]!='\0') {
                    if(m==pole[j][k]) {
                         tmp++;
                         
                    }
                    printf("%c",pole[j][k]);
                    k++;
               }
               j=j+delitel;
               
          }
          if(tmp!=0) {
        printf("%d:%d",i,tmp);
          }
          m=m-1;
     }


}


int main(int argc, const char** argv)
{
     FILE *fr;
     char **pole,c;
     int pozicia;

     int spustene=0,end=1,vytvorene=0,mnozstvo=0,max_dlzka=0;
     while(end==1) {
          switch(getchar()) {
               case 'v':
                    spustene=v_vypis_zaznamu(&fr);

                    break;
               case 'd':
                    if(spustene==0) {

                         precitaj_ulicu();

                    } else {
                         d_najvyzsia_dan(&fr);
                    }
                    break;

               case 'n':
                    if(spustene==0) {}
                    else {

                         vytvorene= n_vytvorenie_pola(&fr,vytvorene,&mnozstvo,&max_dlzka,&pole);



                    }
                    break;
               case 'r':
                    if(vytvorene==0) {
                         printf("Pole nie je vytvorene\n");
                    } else {

                         r_vypis_pola(pole,mnozstvo,max_dlzka);
                    }
                    break;
               case 'h':
                    if(vytvorene==0) {
                         printf("Pole nie je vytvorene\n");
                    } else {

                         h_hystagram(pole,mnozstvo);
                    }
                    break;

               case 'x':
                    x_histagram2(pole,mnozstvo);
                    break;
               case 'p':
                    if(vytvorene==0) {

                         precitaj_ulicu();

                    } else {
                         pole=p_funkcia_pridaj(&pole,&mnozstvo);
                    }
                    break;



               case 'k':
                    end=0;
          }
     }



     return 0;
}
