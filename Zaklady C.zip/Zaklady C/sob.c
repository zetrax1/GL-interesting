/*
* autor - Vladim�r Ve�erek
* n�zov -sob.c
* verzia -
* d�tum -2017
*/
// uloha8-1.c -- Vladim�r Ve�erek, 8.12.2017 13:24

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int *ptmp;
int pocetN=0;
int N,M,celkom,V=0;
int X=0,Y=0;
char mapa[1000][1000];

struct policko{

	int sur_pred[2];
	int vzdialenost;

};

struct tmpbunka{

	int sur[2];

};

struct tsusedia{
	int existuje[4];
	int vlavo[2];
	int vpravo[2];
	int hore[2];
	int dole[2];

};

typedef struct tmpbunka bunka;
typedef struct policko policko;
typedef struct tsusedia susedia;

struct policko **pole;
susedia *sused =NULL;
bunka **tmp=NULL;



void zisti_susedov(int x,int y ){

	if(sused == NULL){
		sused = (susedia*)malloc(sizeof(susedia));
	}
	sused->existuje[0]=0;
	sused->existuje[1]=0;
	sused->existuje[2]=0;
	sused->existuje[3]=0;

	//existuje  0hore,1dole,2vlavo,3vpravo
	if (x != 0 && mapa[y][x - 1] != '#') {
		sused->existuje[2] = 1;
		sused->vlavo[0] = x - 1;
		sused->vlavo[1] = y;
	}


	if (x != M - 1 && mapa[y][x + 1] != '#' ) {
		sused->existuje[3] = 1;
		sused->vpravo[0] = x + 1;
		sused->vpravo[1] = y;
	}

	if (y != 0 && mapa[y - 1][x] != '#') {
		sused->existuje[0] = 1;
		sused->hore[0] = x;
		sused->hore[1] = y - 1;
	}
	if (y != N - 1 && mapa[y + 1][x] != '#') {
		sused->existuje[1] = 1;
		sused->dole[0] = x;
		sused->dole[1] = y + 1;
	}


return;


}

void pridaj_do_tmp(int x,int y,int pozicia){



//	int debag2 =ptmp[pozicia];
	ptmp[pozicia]++;
	int i=0;
//	int debag =ptmp[pozicia];
//	tmp[pozicia]= (bunka*)realloc(tmp[pozicia],((ptmp[pozicia]+1)*sizeof(bunka)));

	bunka *pom;
	pom=(bunka*)malloc((ptmp[pozicia]+1)*sizeof(bunka));

	while(i<ptmp[pozicia]){
		pom[i].sur[0]=tmp[pozicia][i].sur[0];
		pom[i].sur[1]=tmp[pozicia][i].sur[1];
		i++;
	}

//	free(tmp[pozicia]);

	tmp[pozicia]=pom;

	tmp[pozicia][ptmp[pozicia]-1].sur[0]=x;

	tmp[pozicia][ptmp[pozicia]-1].sur[1]=y;

	return;


}

//odstr�ni spola jeden prvok podla suradnic
void odstran_z_tmp(int x,int y,int pozicia){

	int i=0,j=0;
	bunka *pom;
	pozicia++;
	pozicia=pozicia%2;
	pom=(bunka*)malloc(ptmp[pozicia]*sizeof(bunka));

//neodebagovane pozri sa na to ci to nema byt <	miesto !=
	while(i < ptmp[pozicia]){

		pom[j].sur[0]=tmp[pozicia][i].sur[0];
		pom[j].sur[1]=tmp[pozicia][i].sur[1];
		i++;
		j++;
		if(tmp[pozicia][i].sur[1] == y && tmp[pozicia][i].sur[0] == x){
			i++;

		}


	}

//	free(tmp[pozicia]);
	tmp[pozicia]=pom;
	ptmp[pozicia]--;

}
void aktualizuj(int x ,int y){

	//existuje = 0hore,1dole,2vlavo,3vpravo
	int cena ,hodnota;
	zisti_susedov(x, y);

    cena =1;
	hodnota =pole[y][x].vzdialenost;

	int pozicia =(hodnota+cena)%2;


	// podmienka na suseda hore
	if(sused->existuje[0] ==1 && (pole[sused->hore[1]][sused->hore[0]].vzdialenost ==0 || pole[sused->hore[1]][sused->hore[0]].vzdialenost > hodnota+cena)&& !(sused->hore[0] == X && sused->hore[1] == Y)){
		if(pole[sused->hore[1]][sused->hore[0]].vzdialenost !=0 && ptmp[(pozicia+1)%2]!=1){
			odstran_z_tmp(sused->hore[0],sused->hore[1], pozicia);
		}
		if( ptmp[(pozicia+1)%2]==1 && pole[sused->hore[1]][sused->hore[0]].vzdialenost !=0){
			 ptmp[(pozicia+1)%2]--;
		}
		pridaj_do_tmp(sused->hore[0],sused->hore[1], pozicia);
		pole[sused->hore[1]][sused->hore[0]].vzdialenost = hodnota+cena;
		pole[sused->hore[1]][sused->hore[0]].sur_pred[0]=x;
		pole[sused->hore[1]][sused->hore[0]].sur_pred[1]=y;


	}
	//dole
	if(sused->existuje[1] ==1 && (pole[sused->dole[1]][sused->dole[0]].vzdialenost ==0 || pole[sused->dole[1]][sused->dole[0]].vzdialenost > hodnota+cena)&& !(sused->dole[0] == X && sused->dole[1] == Y)){
		if (pole[sused->dole[1]][sused->dole[0]].vzdialenost != 0 &&  ptmp[(pozicia+1)%2]!=1) {
			odstran_z_tmp(sused->dole[0], sused->dole[1], pozicia);
		}
		if( ptmp[(pozicia+1)%2]==1 && pole[sused->dole[1]][sused->dole[0]].vzdialenost != 0 ){
					 ptmp[(pozicia+1)%2]--;
		}

		pridaj_do_tmp(sused->dole[0], sused->dole[1], pozicia);
		pole[sused->dole[1]][sused->dole[0]].vzdialenost = hodnota+cena;
		pole[sused->dole[1]][sused->dole[0]].sur_pred[0]=x;
		pole[sused->dole[1]][sused->dole[0]].sur_pred[1]=y;
	}
	//vlavo
	if(sused->existuje[2] ==1 && (pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost ==0 || pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost > hodnota+cena) && !(sused->vlavo[0] == X && sused->vlavo[1] == Y)){
		if (pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost != 0 &&  ptmp[(pozicia+1)%2]!=1) {
			odstran_z_tmp(sused->vlavo[0], sused->vlavo[1], pozicia);
		}
		if( ptmp[(pozicia+1)%2]==1 && pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost != 0){
					 ptmp[(pozicia+1)%2]--;
				}

		pridaj_do_tmp(sused->vlavo[0], sused->vlavo[1], pozicia);
		pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost = hodnota+cena;
		pole[sused->vlavo[1]][sused->vlavo[0]].sur_pred[0]=x;
		pole[sused->vlavo[1]][sused->vlavo[0]].sur_pred[1]=y;
	}
	//vpravo
	if(sused->existuje[3] ==1 && (pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost ==0 || pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost > hodnota+cena)&& !(sused->vpravo[0] == X && sused->vpravo[1] == Y)){
		if (pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost != 0 &&  ptmp[(pozicia+1)%2]!=1) {
			odstran_z_tmp(sused->vpravo[0], sused->vpravo[1], pozicia);
		}
		if( ptmp[(pozicia+1)%2]==1 && pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost != 0){
					 ptmp[(pozicia+1)%2]--;
			}

		pridaj_do_tmp(sused->vpravo[0], sused->vpravo[1], pozicia);
		pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost = hodnota+cena;
		pole[sused->vpravo[1]][sused->vpravo[0]].sur_pred[0]=x;
		pole[sused->vpravo[1]][sused->vpravo[0]].sur_pred[1]=y;


	}

}



void zisti_cestu_od(int x,int y ){

//malloc nov�ho pomocn�ho pola velkost 3*1

	tmp = (struct tmpbunka**) malloc(2 * sizeof(struct tmpbunka));
	for (int i = 0; i < 2; i++) {
		tmp[i] = (struct tmpbunka*) malloc(1 * sizeof(struct tmpbunka));
	}

	ptmp =(int*)malloc(2*sizeof(int));
	ptmp[0]=0;
	ptmp[1]=0;




//zap�sanie si v�chodiskov�ho bodu

	pole[y][x].vzdialenost = 0;
	int i=0;
	int hodnota = 0;
	int preklop=1;
	X=x;
	Y=y;


aktualizuj(x, y);


int pa=0;

		for(int i=0;i<N;i++){
		for(int j=0;j<M;j++){
			if(mapa[i][j] == '.'){
				celkom++;
			}
		}
	}



	while(i != celkom){
		i++;


		for(int j=0;j<ptmp[preklop];j++){

		//	printf (" %d prave sa aktualizuju suradnice  [%d %d] \n",pa,tmp[preklop][j].sur[0],tmp[preklop][j].sur[1] );
		//	printf("%d %d %d  \n",pa, pole[tmp[preklop][j].sur[1]][tmp[preklop][j].sur[0]].sur_pred[0], pole[tmp[preklop][j].sur[1]][tmp[preklop][j].sur[0]].sur_pred[1]);
			aktualizuj(tmp[preklop][j].sur[0], tmp[preklop][j].sur[1]);
			pa++;


		}

	//	free(tmp[preklop]);
		tmp[preklop] = (struct tmpbunka*) malloc(1 * sizeof(struct tmpbunka));
		ptmp[preklop]=0;

		preklop++;
		preklop=preklop%2;
	}


}

void vypis_mapu(int n ,int m){

	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
//printf("mapa[%d][%d]='%c'; \n ",i,j,mapa[i][j]);
	printf("%c",mapa[i][j]);
		}
		printf("\n");


	}
	printf("\n");
	return;
}

void konvertni(int x,int y , int x2 ,int y2){

	int x4=x,y4=y;
	int x3;
	mapa[y][x]='*';
		while(!(y2 == pole[y][x].sur_pred[1] && x2 == pole[y][x].sur_pred[0])){
			x3=x;
			x=pole[y][x].sur_pred[0];
			y=pole[y][x3].sur_pred[1];

		//	printf("%d %d ",x,y);

			mapa[y][x]='*';


		}





	return ;
}


int main()
{

	char c[1000];
	char d[1000];

	int n=0,m=0,k=0,x=0,y=0;

   gets(c);
   m= strlen(c);
	while(strcmp(c,d)!=0 ){
	//	printf("%s \n",c);
		strcpy(d,c);
		strcpy(mapa[k],d);

		 gets(c);
		k++;
		n++;

	}

/*
	mapa[0][0]='#';
	 mapa[0][1]='.';
	 mapa[0][2]='#';
	 mapa[0][3]='#';
	 mapa[0][4]='#';
	 mapa[0][5]='#';
	 mapa[0][6]='#';
	 mapa[0][7]='#';
	 mapa[0][8]='#';
	 mapa[0][9]='#';
	 mapa[0][10]='#';
	 mapa[0][11]='#';
	 mapa[0][12]='#';
	 mapa[0][13]='#';
	 mapa[0][14]='#';
	 mapa[0][15]='#';
	 mapa[0][16]='#';

	mapa[1][0]='#';
	 mapa[1][1]='.';
	 mapa[1][2]='.';
	 mapa[1][3]='.';
	 mapa[1][4]='#';
	 mapa[1][5]='.';
	 mapa[1][6]='.';
	 mapa[1][7]='.';
	 mapa[1][8]='.';
	 mapa[1][9]='.';
	 mapa[1][10]='.';
	 mapa[1][11]='.';
	 mapa[1][12]='.';
	 mapa[1][13]='.';
	 mapa[1][14]='.';
	 mapa[1][15]='.';
	 mapa[1][16]='#';

	mapa[2][0]='#';
	 mapa[2][1]='.';
	 mapa[2][2]='#';
	 mapa[2][3]='#';
	 mapa[2][4]='#';
	 mapa[2][5]='.';
	 mapa[2][6]='#';
	 mapa[2][7]='#';
	 mapa[2][8]='#';
	 mapa[2][9]='#';
	 mapa[2][10]='#';
	 mapa[2][11]='.';
	 mapa[2][12]='#';
	 mapa[2][13]='.';
	 mapa[2][14]='#';
	 mapa[2][15]='#';
	 mapa[2][16]='#';

	mapa[3][0]='#';
	 mapa[3][1]='.';
	 mapa[3][2]='.';
	 mapa[3][3]='.';
	 mapa[3][4]='.';
	 mapa[3][5]='.';
	 mapa[3][6]='.';
	 mapa[3][7]='.';
	 mapa[3][8]='.';
	 mapa[3][9]='.';
	 mapa[3][10]='#';
	 mapa[3][11]='.';
	 mapa[3][12]='#';
	 mapa[3][13]='.';
	 mapa[3][14]='.';
	 mapa[3][15]='.';
	 mapa[3][16]='#';

	mapa[4][0]='#';
	 mapa[4][1]='#';
	 mapa[4][2]='#';
	 mapa[4][3]='#';
	 mapa[4][4]='#';
	 mapa[4][5]='#';
	 mapa[4][6]='#';
	 mapa[4][7]='#';
	 mapa[4][8]='#';
	 mapa[4][9]='#';
	 mapa[4][10]='#';
	 mapa[4][11]='#';
	 mapa[4][12]='#';
	 mapa[4][13]='#';
	 mapa[4][14]='#';
	 mapa[4][15]='.';
	 mapa[4][16]='#';
*/



	n=n-1;
	N=n;
	M=m;
	printf("%d %d",n-1,m);

	pole = (struct policko**) malloc(n * sizeof(struct policko));
	for (int i = 0; i < n; i++) {
		pole[i] = (struct policko*) malloc(m * sizeof(struct policko));
		for(int j=0;j<m;j++){
		pole[i][j].vzdialenost =0;
		}
	}


    zisti_cestu_od(x, y);
//	vypis_mapu(n ,m);
	konvertni( m-2,n-1,x,y);
	vypis_mapu(n ,m);




	return 0;
}
