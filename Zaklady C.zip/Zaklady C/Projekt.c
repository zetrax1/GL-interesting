/*
 * autor - Vladim�r Ve�erek
 * n�zov -Projekt.c
 * verzia -Finalna
 * d�tum -3.5.2017
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct zoznam_t {
	char priezvisko_meno[52];
	char bydlisko[50];
	int pracovnik;
	float mzda;
	int datum;
	struct zoznam_t *dalsi;
};

typedef struct zoznam_t zoznam;

zoznam * generuj_zoznam() {
	FILE *fr;
	if ((fr = fopen("zamestnanci.txt", "r")) == NULL) {
		printf("Zaznamy neboli nacitane\n ");
	}

	int pocet = 0;
	char c;
	zoznam *tmp, *oblast_1;

	rewind(fr);
	if ((c = getc(fr)) != EOF) {

		tmp = (zoznam *) malloc(sizeof(zoznam));
		ungetc(c, fr);

		fgets(tmp->priezvisko_meno, 51, fr);
		fgets(tmp->bydlisko, 51, fr);
		fscanf(fr, "%d", &tmp->pracovnik);
		fscanf(fr, "%f ", &tmp->mzda);
		fscanf(fr, "%d ", &tmp->datum);

		c = getc(fr);
		c = getc(fr);
		pocet++;

		tmp->dalsi = NULL;
		oblast_1 = tmp;

		while ((c = getc(fr)) != EOF) {

			tmp->dalsi = (zoznam *) malloc(sizeof(zoznam));
			tmp = tmp->dalsi;
			ungetc(c, fr);

			fgets(tmp->priezvisko_meno, 51, fr);
			fgets(tmp->bydlisko, 51, fr);
			fscanf(fr, "%d", &tmp->pracovnik);
			fscanf(fr, "%f ", &tmp->mzda);
			fscanf(fr, "%d ", &tmp->datum);

			c = getc(fr);
			c = getc(fr);

			tmp->dalsi = NULL;
			pocet++;
		}
	}
	fclose(fr);
	printf("Nacitalo sa %d zaznamov \n ", pocet);
	return oblast_1;
}

zoznam * zmazanie_celeho_zoznamu(zoznam *oblast_1) {

	zoznam *tmp, *pred;

	while (oblast_1->dalsi != NULL) {
		tmp = oblast_1->dalsi;
		pred = oblast_1;

		while (tmp->dalsi != NULL) {
			tmp = tmp->dalsi;
			pred = pred->dalsi;
		}
		pred->dalsi = NULL;
		free(tmp);

	}
	free(oblast_1);
	oblast_1 = NULL;

	return oblast_1;

}

void vypis_zoznamu(zoznam *oblast_1) {

	zoznam *pohyb;
	pohyb = oblast_1;
	int a = 1;
	while (pohyb != NULL) {
		printf("%d.\n", a);
		printf("Priezvisko meno: %s", pohyb->priezvisko_meno);
		printf("Bydlisko: %s", pohyb->bydlisko);
		if (pohyb->pracovnik == 1) {
			printf("Riadiaci pracovnik\n");
		} else {
			printf("Bezny zamestnanec\n");
		}
		printf("Hruba mzda: %.2f\n", pohyb->mzda);

		printf("Datum: %d\n", pohyb->datum);

		pohyb = pohyb->dalsi;
		a++;
	}
}

void pridaj(zoznam **oblast_1) {

	zoznam *novy, *tmp, *pred;
	char b;
	novy = (zoznam *) malloc(sizeof(zoznam));

	scanf("%c", &b);
	gets(novy->priezvisko_meno);
	strcat(novy->priezvisko_meno, "\n");
	gets(novy->bydlisko);
	strcat(novy->bydlisko, "\n");
	fflush(stdin);
	scanf("%d", &novy->pracovnik);
	scanf("%f ", &novy->mzda);
	scanf("%d ", &novy->datum);

	int a = 0;

	if ((*oblast_1) == NULL) {
		(*oblast_1) = novy;
		novy->dalsi = NULL;
		return;
	}

	pred = (*oblast_1);
	tmp = (*oblast_1)->dalsi;

	if ((a = strcmp(novy->priezvisko_meno, pred->priezvisko_meno)) <= 0) {
		(*oblast_1) = novy;
		novy->dalsi = pred;
		return;

	}

	while (a >= 0) {
		a = strcmp(novy->priezvisko_meno, tmp->priezvisko_meno);
		if (a <= 0) {
			pred->dalsi = novy;
			novy->dalsi = tmp;
			return;

		}

		if (tmp->dalsi == NULL && a >= 0) {
			tmp->dalsi = novy;
			novy->dalsi = NULL;
			return;
		}

		tmp = tmp->dalsi;
		pred = pred->dalsi;
	}

	return;

}

void aktualizuj_mzdu(zoznam *oblast_1) {

	float m_mzda;
	scanf("%f", &m_mzda);

	zoznam *tmp;
	tmp = oblast_1;
	int pocet = 0;

	while (tmp != NULL) {
		if (tmp->mzda < m_mzda) {
			tmp->mzda = m_mzda;
			pocet++;
		}
		tmp = tmp->dalsi;
	}

}

void vypis_podla_mena(zoznam *oblast_1) {

	zoznam * tmp;
	tmp = oblast_1;

	char porovnaj[52], c, b;
	scanf("%c", &b);
	gets(porovnaj);
	strcat(porovnaj, "\n");
	int a = 1, k = 0, i = 0, j = 0;

	while (tmp != NULL) {

		while ((c = (tmp->priezvisko_meno[i])) != '\0') {
			i++;

		}
		while ((c = (porovnaj[j])) != '\0') {
			j++;

		}

		while (j != 0) {
			if ((tmp->priezvisko_meno[i]) != (porovnaj[j])) {
				k = 1;
				break;
			}
			i--;
			j--;
			if ((tmp->priezvisko_meno[i]) != (porovnaj[j])) {
				k = 1;
				break;
			}

		}
		if (k == 0) {
			printf("%d.\n", a);
			printf("Priezvisko meno: %s", tmp->priezvisko_meno);
			printf("Bydlisko: %s", tmp->bydlisko);
			if (tmp->pracovnik == 1) {
				printf("Riadiaci pracovnik\n");
			} else {
				printf("Bezny zamestnanec\n");
			}
			printf("Hruba mzda: %.2f\n", tmp->mzda);

			printf("Datum: %d\n", tmp->datum);
			a++;

		}
		k = 0;
		j = 0;
		i = 0;
		tmp = tmp->dalsi;
	}
	return;
}

void max_plat_za_rok(zoznam *oblast_1) {

	int rok;
	scanf("%d", &rok);

	zoznam * tmp, *bezny = NULL, *riadiaci = NULL;
	tmp = oblast_1;

	float maxb = 0, maxr = 0;

	/*	while (tmp->pracovnik != 0) {
	 tmp = tmp->dalsi;
	 }
	 maxb = tmp->mzda;
	 tmp = oblast_1;
	 while (tmp->pracovnik != 1) {								ak predpoklad�me z�porn� mzdu
	 tmp = tmp->dalsi;
	 }
	 maxr = tmp->mzda;
	 tmp = oblast_1;*/

	while (tmp != NULL) {

		if ((tmp->datum / 10000) == rok) {
			if (tmp->pracovnik == 0 && maxb <= (tmp->mzda)) {
				maxb = tmp->mzda;
				bezny = tmp;

			}
			if (tmp->pracovnik == 1 && maxr <= (tmp->mzda)) {
				maxr= tmp->mzda;
				riadiaci = tmp;

			}

		}

		tmp = tmp->dalsi;

	}

	if (bezny == NULL && riadiaci == NULL) {
		printf("neexistuje �iaden pracovn�k v zadanom  roku");
		return;
	}
	if (bezny == NULL && riadiaci != NULL) {
		printf("Be�n� zamestnanec neexistuje \n %s", riadiaci->priezvisko_meno);
		return;
	}
	if (bezny != NULL && riadiaci == NULL) {
		printf("%s \n Riadiaci zamestnanec neexistuje ",
				bezny->priezvisko_meno);
		return;
	}

	printf("%s \n %s", bezny->priezvisko_meno, riadiaci->priezvisko_meno);

	return;

}

void zmazanie_duplicitnych(zoznam *oblast_1) {

	zoznam *tmp, *skumany, *pred;
	tmp = oblast_1;
	pred = oblast_1;
	skumany = oblast_1->dalsi;
	int i = 0, j = 0;

	while (tmp != NULL) {

		while (skumany != NULL) {

			j = 0;
			i = 0;
			while (tmp->priezvisko_meno[i] != '\0') {
				if (tmp->priezvisko_meno[i] != skumany->priezvisko_meno[i]) {
					j = 1;
				}
				i++;
			}
			i = 0;
			while (tmp->bydlisko[i] != '\0') {
				if (j != 1 && tmp->bydlisko[i] != skumany->bydlisko[i]) {
					j = 1;
				}
				i++;
			}

			if (j == 0) {
				pred->dalsi = skumany->dalsi;

				free(skumany);

			}

			if (pred->dalsi == NULL) {
				skumany = NULL;
			} else {
				skumany = pred->dalsi->dalsi;
				pred = pred->dalsi;
			}

		}

		tmp = tmp->dalsi;
		if(tmp == NULL){
			return;
		}
		skumany = tmp->dalsi;
		pred = tmp;

	}

}

int main(void) {
	int end = 1;

	zoznam *oblast_1;
	oblast_1 = NULL;

	while (end == 1) {

		switch (getchar()) {
		case 'n':
			if (oblast_1 != NULL) {
				oblast_1 = zmazanie_celeho_zoznamu(oblast_1);
			}
			oblast_1 = generuj_zoznam();
			break;
		case 'v':
			if (oblast_1 == NULL) {
			} else {
				vypis_zoznamu(oblast_1);
			}
			break;
		case 'p':
			pridaj(&oblast_1);
			break;
		case 'm':
			if (oblast_1 != NULL) {
			max_plat_za_rok(oblast_1);
			}
			break;
		case 'h':
			if (oblast_1 != NULL) {
			vypis_podla_mena(oblast_1);
			}
			break;
		case 'a':
			if (oblast_1 != NULL) {
				aktualizuj_mzdu(oblast_1);
						}

			break;
		case 'z':
			if (oblast_1 != NULL) {
			zmazanie_duplicitnych(oblast_1);
			}
			break;
		case 'k':
			end = 0;
			break;
		}
	}

	return 0;
}
