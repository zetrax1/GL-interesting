/*
 ============================================================================
 Name        : Projekt 2.c
 Author      : Vecerek
 Version     : 1.6
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>


struct zoznam_t {
     char priezvisko_meno[52];
     char bydlisko[50];
     int pracovnik;
     float mzda;
     int datum;
     struct zoznam_t *dalsi;
};

typedef struct zoznam_t zoznam;


zoznam * generuj_zoznam ()
{
     FILE *fr;
     if ((fr = fopen ("zamestnanci.txt", "r")) == NULL) {
          printf ("Zaznamy neboli nacitane\n ");
     }

     int pocet = 0;
     char c, a;
     zoznam *tmp, *oblast_1;
		
	rewind(fr);	
	if((c=getc(fr))!= EOF){
	
     oblast_1 = (zoznam *) malloc (sizeof(zoznam));
     
     c=getc(fr);
     printf("%c",c);
     fgets (oblast_1->priezvisko_meno, 51, fr);
     printf("%s \n",oblast_1->priezvisko_meno);
     fgets (oblast_1->bydlisko,51, fr);
     printf("%s \n",oblast_1->bydlisko);
     fscanf (fr, "%d ",oblast_1->pracovnik);
     printf("%d",oblast_1->pracovnik);
     fscanf (fr, "%f ",oblast_1->mzda);
     printf("%.2f",oblast_1->mzda);
     fscanf (fr, "%d ",oblast_1->datum);
     printf("%d",oblast_1->datum);


//     while (a == '*') {
//          tmp->dalsi = (zoznam *) malloc (sizeof(zoznam));
//          tmp = tmp->dalsi;
//          fscanf (fr, "%s\n", hviezdicka);
//          fgets (tmp->signatura, 10, fr);
//          fgets (tmp->isbn, 30, fr);
//          fgets (tmp->nazov, 100, fr);
//          fgets (tmp->autor, 100, fr);
//          fscanf (fr, "%d ", &tmp->datum);
//          fscanf (fr, "%d \n", &tmp->c_preukaz);
//          a = fgetc (fr);
//          tmp->dalsi = NULL;
//          pocet++;
//     }
}
     fclose (fr);
     printf ("Nacitalo sa %d zaznamov \n ", pocet);
     return oblast_1;
}


int main (void)
{
     int end = 1;

     zoznam *oblast_1;
     oblast_1 = NULL;

     while (end == 1) {

          switch (getchar ()) {
               case 'n':
                    oblast_1 = generuj_zoznam ();
                    break;
               case 'v':

                    break;
               case 'p':

                    break;
               case 'z':

                    break;
               case 'h':

                    break;
               case 'a':

                    break;
               case 'k':
                    end = 0;
                    break;
          }
     }

     system ("PAUSE");
     return 0;
}
