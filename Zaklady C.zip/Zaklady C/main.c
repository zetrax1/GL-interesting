
/*
 *      spojenie.c
 *
 *  Created on: 20.11.2017
 *      Author: Vladimír Večerek
 */

#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <arpa/inet.h>
#include <sys/socket.h>
#include <time.h>

#define Velkost 9

int cas, pripojenie, koniec,s,zaistitel;
clock_t cas_pripojenia,cas_pocuvania;

struct hlavicka_s{
    char typ_spravy;
    int dalsi;
    int prvy;
    char *crc;
};

typedef struct hlavicka_s hlavicka;


struct hlavicka_server{
    char typ_spravy;
    int dalsi;
    int prvy;
};

typedef struct hlavicka_server hl_s;


struct nite{
    int spojenie;
    int velkost;
    struct sockaddr_in si_server;
};

typedef struct nite nite;

struct hlavicka_s *kontrolna;
struct hlavicka_server *pomocna;

void transformuj( unsigned char *pole){
    
    kontrolna->typ_spravy = pole[0];
    int pom=0,t=1;

   for(int i=1;i<5;i++){
        pom+= t*(int)pole[i]*256;
        t *= 256;
    }
    
    kontrolna->dalsi = pom;
    
    pom=0;
    t=1;
    for(int i=5;i<9;i++){
        pom+= t*(int)pole[i]*256;
		t *= 256;
    }
    kontrolna->prvy=pom;
    
    return;
    }

void zapis_do_pola(unsigned char *pole ){
    
    //priprava miesta na crc aby -potrebne len pre kontrolu kodu
    pole[9]=' ';
    pole[10]=' ';
    int a =kontrolna->prvy;
    int b=kontrolna->dalsi;
    //prepis z štruktury do tvaru pola 
    pole[0]='m';
    for(int i=1; i<5; i++){
		pole[i] = (char)((int)a%256);
	    a /= 256;
	}
	for(int i=5; i<9; i++){
		pole[i] = (int)b%256;
		b /= 256;
	}
    
}  

void *vlakno(struct nite *vlakno){
    char keepAlive[5];
    memset(keepAlive, '-', 5);
    while(1){
        sendto(vlakno->spojenie, keepAlive, 5, 0, (struct sockaddr *) &vlakno->si_server, vlakno->velkost);
        sleep(0.5);
    }
    return NULL;
}

void die(unsigned char *s){
    perror(s);
    exit(1);
}

void prve_pole_priamo(int celkova_dlzka, int pocet_frag,  unsigned char *pole ){
	
       pole[0] = 'm';
       
	for(int i=1; i<5; i++){
		pole[i] = (int)celkova_dlzka%256;
		pole[i+4] = (int)pocet_frag%256;
	    celkova_dlzka /= 256;
	    pocet_frag /= 256;
	}
}

//crc 
unsigned short crcCode(unsigned char *data, unsigned int dlzka){
    unsigned short CRC;
    unsigned char help;
    CRC = 1;
    for(int i=0; i<dlzka; i++ ){
        help = data[i];
        for(int x=0; x<8; x++ ){
            if( CRC & 0x8000 ){
                CRC = (CRC<<1) | (help & 1);
                CRC ^= 0x1083;
            }
            else
                CRC = (CRC<<1)| (help & 1);
            help >>= 1;
        }
    }
    return CRC;
}

int crcCorrect(unsigned char *message, int fragment, int first, int last){
    int crc1 = message[9];
    int crc2 = message[10];
    message[9] = ' ';
    message[10] = ' ';
    if((int)crc1 == (int)((unsigned char)(crcCode(message, last-first+11)&0xF)) && (int)crc2 == (int)((unsigned char)crcCode(message, last-first+11)&0xF0)){
        return 1;
    }
    printf("Nespravny paket\n");
    return 0;
}


void pripoj_hlavicku( unsigned char *pole,  unsigned char *blok, int velkost){
	int pozicia=11;
	uint16_t crc;
    int dlzka;
	for(int i=kontrolna->prvy; i<kontrolna->dalsi; i++){
            if(i>=velkost){
                blok[pozicia]=' ';
                dlzka = i;
                kontrolna->dalsi = dlzka;
                break;
            }else{
                blok[pozicia] = pole[i];
            }
            pozicia++;
	}
    
    
    zapis_do_pola(blok);
	crc = crcCode(blok, kontrolna->dalsi-kontrolna->prvy+11);
    
	blok[9] = crc & 0xF;
	blok[10] = crc & 0xF0;
}

//ak to nepojde alebo bude cas skus zmenit cez funkciu transformuj
int urc_dalsi(unsigned char *novy, int x){
	int prvy = 0, t = 1;
	for(int i=0; i<x; i++){
		prvy = prvy + t*(int)novy[i];
		t *= 256;
	}
	return prvy;
}

// pouzi strukturu
void zisti_v_balika( unsigned char *balicek, int *v_blok, int *v_balik, int *v_celkovo, char *sprava){
    int t = 1, i;
    sprava[0] = 'm';
    
    *v_balik = 0;
    *v_blok= 0;
    for(i=1; i<5; i++){
        *v_blok = *v_blok + t*(int)balicek[i];
        *v_balik = *v_balik + t*(int)balicek[i+4];
        t *= 256;
    }
    *v_celkovo = *v_balik - 11;
}

//pouzi strukturu
void zisti_v_balika2( unsigned char *balicek, int *prvy, int *druhy){
    int tmp = 1, i;
    if(*balicek != 'm'){
        *prvy = -1;
        pomocna->prvy =prvy;
        return;
    }
    *prvy = 0;
    *druhy = 0;
    for(i=1; i<5; i++){
        *prvy = *prvy + tmp*(int)balicek[i];
        *druhy = *druhy + tmp*(int)balicek[i+4];
        tmp *= 256;
    }
}

void *server_c(void *vstup){
    char a;
    while(1){
        scanf("%c", &a);
        if(a=='k'){
            koniec = 1;
            break;
        }
    }
    
}

void urc_dalsi2(unsigned char *odpoved, int posledne){
    for(int i=0; i<4; i++){
        odpoved[i] = posledne%256;
        posledne /= 256;
    }
}

void *fun_klient(void *nieco){
   // inicializácia 
    struct sockaddr_in  si_other;
    int port,prvy,druhy, velkost_data, dlzka_socetu = sizeof(si_other) , v_fragment,celkova_v,pocet_b ,znak ,i ,moznost;
    unsigned char adresa[15], zaciatokP[9], z_sprava[5], c[2], mini_pole[4], sprava[1500], *message;
  
    
    
    memset((unsigned char *) &si_other, 0, sizeof(si_other));
    message = (unsigned char*)malloc(5000*sizeof(unsigned char));
    znak = getchar();
    
    //bez tohto die to nejde  
    if ((s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)die("socket");
    
    // okno klient 
    for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 57; j++) {
			if (i % 2 == 0 && j % 2 == 0) {
				printf("*");
			} else
				printf("§");
		}
		printf("\n");
	}
	printf("*§*                                                   *§*\n");
	printf("*§*              Vitajte v režime klient              *§*\n");
	printf("*§*                                                   *§*\n");

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 57; j++) {
			if (i % 2 == 0 && j % 2 == 0) {
				printf("*");
			} else
				printf("§");
		}
		printf("\n");
	}
    
    printf("Zadajte port: \n");
    scanf("%d", &port);
    printf("Zadajte IP adresu servera: ");
    scanf("%s", adresa);
 // koniec okno klient    
    
    
    while(1){
        printf("Zadaj maximalnu velkost fragmentu z intervalu 40-1500 : ");
        scanf("%d", &v_fragment);
        if(v_fragment >= 40 && v_fragment <= 1500)break;
        printf("Zadane cislo nieje z intervalu.\n");
    }
    
    
    v_fragment -= 28;
    velkost_data = v_fragment - Velkost - 2;
    
  //funkcie pre funkčnosť programu - nastavenia servera  
    si_other.sin_family = AF_INET;
    si_other.sin_port = htons(port);
    if (inet_aton(adresa , &si_other.sin_addr) == 0){exit(1);}
    
    
    
  //inicializácia struktúri nite :názov vlakno  
    nite *vlakno;
    vlakno = (struct nite*)malloc(sizeof(struct nite));
    vlakno->velkost = sizeof(si_other);
    vlakno->si_server = si_other;
    vlakno->spojenie = s;
    pthread_t dalsie_v;
    
    while(1){
        i=0;
        pocet_b = 0;
       // funkcie na vytvorenie thread 
//        pthread_create(&dalsie_v, NULL, vlakno, (void *)vlakno);
        
        
            for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 57; j++) {
			if (i % 2 == 0 && j % 2 == 0) {
				printf("*");
			} else
				printf("§");
		}
		printf("\n");
	}
    printf("*§*                                                   *§*\n");
	printf("*§*                   moznosti                        *§*\n");
    printf("*§*             0 Odhlasenie klienta                  *§*\n");
    printf("*§*             1 Poslanie spravy                     *§*\n");
	printf("*§*             2 Poslanie chybneho paketu            *§*\n");
	printf("*§*                                                   *§*\n");

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 57; j++) {
			if (i % 2 == 0 && j % 2 == 0) {
				printf("*");
			} else
				printf("§");
		}
		printf("\n");
	}
        
        
    scanf("%d", &moznost);
    
    //moznost 0 odhlasenie sa 
        if(moznost==0){
            close(s);
            pthread_cancel(dalsie_v);
            break;
        }
        
        
    //
        if(moznost == 1 || moznost == 2){
            printf("Zadajte text spravy : ");
            while(1){
                znak = getchar();
                if(znak == '\n'){
                    znak = getchar();
                    if(znak == '\n')break;
                    else {
                        message[i] = '\n';
                        message[++i] = znak;
                    }
                }
                message[i++] = znak;
            }
            message[i] = '\0';
            celkova_v = i;
        }

        pthread_cancel(dalsie_v);
        //nadviazanie spojenia
        do{
            prve_pole_priamo(celkova_v, v_fragment, z_sprava);
            cas_pocuvania = clock();
            pripojenie = 1;
            sendto(s, z_sprava, Velkost, 0 , (struct sockaddr *) &si_other, dlzka_socetu);
            pripojenie = 0;
            recvfrom(s, c, 2, 0, (struct sockaddr *) &si_other, &dlzka_socetu);
            cas_pocuvania = clock();
            pripojenie = 1;
        }while(c[0]!=':'&&c[1]!=')');
        //poslanie spravy
        
        druhy = 0;
        
        while(1){
            //prenastavienie hodnôt prvy a druhy 
            prvy = druhy;
            druhy = druhy+velkost_data;
            kontrolna->prvy = prvy;
            kontrolna->dalsi = druhy;
            
            //nastavenie ich do pola 
            zapis_do_pola(sprava);
            pripoj_hlavicku(message, sprava, celkova_v);
            
            prvy = kontrolna->prvy;
            druhy = kontrolna->dalsi;
            //nastavenie chiboveho crc
            if(moznost == 2){
                sprava[9] = sprava[9]+1;
                moznost = 1;
            }
            
            
            
            cas_pocuvania = clock();
            pripojenie = 1;
            pocet_b++;
            
            printf("Odoslalo %d. paket s velkostou %d bytov.\n", pocet_b, druhy-prvy+11+28);
            //testovacie spravy
            sendto(s, sprava, druhy-prvy+11, 0 , (struct sockaddr *) &si_other, dlzka_socetu);
            pripojenie = 0;
            recvfrom(s, mini_pole, 4, 0, (struct sockaddr *) &si_other, &dlzka_socetu);
            cas_pocuvania = clock();
            pripojenie = 1;
            druhy = urc_dalsi(mini_pole, 4);
            kontrolna->dalsi=druhy;
            
            
            
            //ukoncenie vysielania
            if(druhy >= celkova_v){
                c[0] = ':';
                c[1] = ')';
                sendto(s, c, 2, 0 , (struct sockaddr *) &si_other, dlzka_socetu);
                recvfrom(s, c, 2, 0, (struct sockaddr *) &si_other, &dlzka_socetu);
                if(c[0] == ':' && c[1] == ')'){
                    if(moznost == 2){
                        printf("Subor bol uspesne odoslany\n");
                    }
                    printf("Bolo odoslanych %d paketov\n", pocet_b);
                    pripojenie = -1;
                    break;
                }
            }
        }
        
    }
    koniec = 1;
    return;
}



void *fun_server(void *nieco){
    
    struct sockaddr_in si_me, si_other;
    int velkost_s = -1, velkost_b, velkost_data, tmp, tmp2, pocet_p, port, prvy, druhy, dlzka_s,pocet_b;
    unsigned char zaciatokP[9], c[2], mini_pole[4], sprava[1500], *message; 
    dlzka_s = sizeof(si_other);
    //nastavenie
    memset(( unsigned char *) &si_me, 0, sizeof(si_me));
    memset(zaciatokP, '?', 5);
    
    
    //zase ta vec aby to išlo
    if ((s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)die("socket");
    
    
    for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 57; j++) {
			if (i % 2 == 0 && j % 2 == 0) {
				printf("*");
			} else
				printf("§");
		}
		printf("\n");
	}
	printf("*§*                                                   *§*\n");
	printf("*§*              Vitajte v režime server              *§*\n");
	printf("*§*                                                   *§*\n");

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 57; j++) {
			if (i % 2 == 0 && j % 2 == 0) {
				printf("*");
			} else
				printf("§");
		}
		printf("\n");
	}
    
    
    
    printf("\n Zadajte port: \n");
    scanf("%d", &port);
    
    printf("\n Pre koniec stlacte k a potvrdte enterom \n");
    
    
    
    //spojenie 
    si_me.sin_family = AF_INET;
    si_me.sin_port = htons(port);
    si_me.sin_addr.s_addr = htonl(INADDR_ANY);

    //bind 
    if( bind(s , (struct sockaddr*)&si_me, sizeof(si_me) ) == -1)die("bind");
    
    zaistitel = 1;
    
    printf("Cakam na data...\n");
    zaistitel = 1;
    
    
    while(1){
        pocet_p = 0;
        pocet_b = 0;
        velkost_s = -1;
        
        //komunikácia server klient kym  si neposlu spravu 
        do{
            
            //sprava o pripojeni 
            pripojenie = 0;
            recvfrom(s, zaciatokP, 9, 0, (struct sockaddr *) &si_other, &dlzka_s);
            cas_pripojenia = clock();
            pripojenie = 1;
            
            
            
            if(zaciatokP[0] == '?' && zaciatokP[1] == '?' && zaciatokP[2] == '?' && zaciatokP[3] == '?' && zaciatokP[4]== '?'){
                //sendto(s, initPaket, 5, 0, (struct sockaddr*) &si_other, dlzka_s);
                continue;
            }
            
            zisti_v_balika(zaciatokP, &velkost_s, &velkost_b, &velkost_data,sprava);
            
            if(velkost_s>0){
                c[0] = ':';
                c[1] = ')';
            }
            else {
                c[0] = ':';
                c[1] = '(';
            }
            sendto(s, c, 2, 0, (struct sockaddr*) &si_other, dlzka_s);
            
        }while(velkost_s<1);
        
        // spojenie nadviazane 
        prvy = 0;
        message = (unsigned char*)malloc(velkost_s*sizeof(unsigned char));
        
        
        while(1){
            pripojenie = 10;
            pocet_p++;
            recvfrom(s, sprava, velkost_b, 0, (struct sockaddr *) &si_other, &dlzka_s);
            cas_pripojenia = clock();
            pripojenie = 1;
            
            
            //precitanie spravy ,pouzi strukturu
            tmp2 = prvy;
            
            zisti_v_balika2(sprava, &prvy, &druhy);
            //  prvy=pomocna->prvy;
           // druhy=pomocna->dalsi;
            tmp =prvy;
            
            
            
            //zistenie ci prisiel spravny balik a ci ho treba znova vyžiadať 
            if(prvy == -1 || crcCorrect(sprava, velkost_b, prvy, druhy) != 1){
                urc_dalsi(mini_pole, 0);
                sendto(s, mini_pole, 4, 0, (struct sockaddr*) &si_other, dlzka_s);
                pocet_p++;
                continue;
            }
            else {
                printf("%d. paket, prislo %d bytov\n", (pocet_p+1)/2, druhy-prvy+11+28);
                
                for(int i=11; i<velkost_b; i++){
                    message[tmp++] = sprava[i];
                    if(tmp>=velkost_s)break;
                }
                pocet_p++;
                if(druhy >= velkost_s){
                    urc_dalsi2(mini_pole, druhy+10);
                }
                else urc_dalsi2(mini_pole, druhy);
            }
            
            
            sendto(s, mini_pole, 4, 0, (struct sockaddr*) &si_other, dlzka_s);
          



  //ukoncenie
            if(druhy >= velkost_s){
                unsigned char end[2];
                while(1){
                    recvfrom(s, end, 2, 0, (struct sockaddr *) &si_other, &dlzka_s);
                    if(end[0]==':'&&end[1]==')'){
                        sendto(s, end, 2, 0, (struct sockaddr*) &si_other, dlzka_s);
                        printf("Prislo %d paketov\n\n", pocet_p/2);
                            for(int i=0; i<velkost_s; i++){
                                printf("%c", message[i]);
                            }
                            printf("\n\n\n");
                            prvy = 0;
                            break;

                        
                    }
                    sendto(s, end, 2, 0, (struct sockaddr*) &si_other, dlzka_s);
                }
                break;
            }
        }
    }
}







int main() {

	int key;
    
    kontrolna = (struct hlavicka_s*)malloc(sizeof(hlavicka));
    pomocna = (struct hlavicka_server*)malloc(sizeof(hl_s));
    
	while(1){

//aplikačné menu
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 57; j++) {
			if (i % 2 == 0 && j % 2 == 0) {
				printf("*");
			} else
				printf("§");
		}
		printf("\n");
	}
	printf("*§*                                                   *§*\n");
	printf("*§*            Vitajte v aplikacnom menu              *§*\n");
	printf("*§*  Pre zobrazenie informácií o aplikácií stlačte 1  *§*\n");
	printf("*§*  Pre spustenie v mode klient stlacte 2            *§*\n");
	printf("*§*  Pre spustenie v mode server stlacte 3            *§*\n");
	printf("*§*  Pre ukončenie aplikácie stlačte 4                *§*\n");
	printf("*§*                                                   *§*\n");

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 57; j++) {
			if (i % 2 == 0 && j % 2 == 0) {
				printf("*");
			} else
				printf("§");
		}
		printf("\n");
	}

//
	scanf("%d", &key);

// informácie o aplikácií
	if (key == 1) {
		printf("\n");
		printf("Meno autora : Vladimír Večerek \n");
		printf("Nazov aplikácie : UDP komunikácia na zadanie z PKS\n");
		printf("Verzia programu : 1.3 B\n");
		printf("Dátum vytvorenia : 20.11.2017\n");
		printf("\n \n \n");
        
        
        scanf("%d", &key);
	}

	
    if(key == 2){
            
            
            int s_pripoj = 1;
            koniec = 0;
            pripojenie = 1;
            // potrebne na spustenie
            zaistitel = 0;
            //
            pthread_t klient;
            pthread_create(&klient, NULL, fun_klient, NULL);
            cas_pocuvania = clock();
            
            while(1){
                if(pripojenie == 1){
                    cas_pocuvania = clock();
                }
                if(pripojenie == 0 && clock()-cas_pocuvania > 3000000){
                    pthread_cancel(klient);
                    close(s);
                    printf("Server odpojeny\n");
                    s_pripoj = -1;
                    break;
                }
           
                if(koniec == 1){
                    koniec = 0;
                    pthread_cancel(klient);
                    close(s);
                    s_pripoj = -1;
                    break;
                }
                
            }
        }

    if (key == 3) {
            
            
            koniec = 0;
            pripojenie = 2;
            
            // taka ta vec bez ktorej to nejde 
            zaistitel = 0;
            
            //zabezpecenie vlakna server 
            pthread_t server, server2;
            pthread_create(&server, NULL, fun_server, NULL);
            cas_pripojenia = clock();
            
            
            
            
            
            
            while(1){
                if(zaistitel == 1){
                    zaistitel = 0;
                    pthread_create(&server2, NULL, server_c, NULL);
                }
                if((pripojenie == 1 || pripojenie == 10) && pripojenie == -1)pripojenie = 1;
                if(pripojenie ==2 &&clock()-cas_pripojenia > 2000000){
                    printf("Klient odpojeny\n");
                    pripojenie = 1;
                }
                if(pripojenie==1&&clock()-cas_pripojenia < 2000000){
                    printf("Klient pripojeny\n");
                    pripojenie = 2;
                }
                if(pripojenie == 10 && clock()-cas_pripojenia > 2000000){
                    pthread_cancel(server2);
                    pthread_cancel(server);
                    close(s);
                    printf("Klient bol odpojeny\n");
                    break;
                }
                if(koniec == 1){
                    koniec = 0;
                    
                    pthread_cancel(server);
                    pthread_cancel(server2);
                    pripojenie = -1;
                    close(s);
                    break;
                }
            
            }
        }


if (key != 1 && key != 2 && key != 3) {

	printf(" neplatný vstup \n zadaná hodnota sa nenachádza v možnostiach menu\n");

}

	}

return 0;

}