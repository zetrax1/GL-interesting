/*
* autor - Vladim�r Ve�erek
* n�zov -verzia1.c
* verzia -
* d�tum -2018
*/

#include<stdio.h>
#include<stdlib.h>


int n=5;
int cislo =0;
int x=0;
int y=0;


struct tmpsusedia{
	int x[8];
	int y[8];
	int skusil[8];
};

typedef struct tmpsusedia susedia;

struct tmpbunka{
	int poradie;
	susedia *moznosti;
	int pocet;
};

typedef struct tmpbunka bunka;

bunka **pole = NULL;
susedia *sused =NULL;

void najdi_susedov(int a ,int b) {

	int i = 0;
	pole[a][y].moznosti = (susedia*) malloc(sizeof(susedia));
//prv� kvadrant
	if (a + 2 <= n && b + 1 <= n) {
		pole[a][y].moznosti->x[i] = a + 2;
		pole[a][y].moznosti->y[i] = b + 1;
		i++;
	}
	if (a + 1 <= n && b + 2 <= n) {
		pole[a][y].moznosti->x[i] = a + 1;
		pole[a][y].moznosti->y[i] = b + 2;
		i++;
	}
//druh� kvadrant
	if (a - 1 >= 0 && b + 2 <= n) {
		pole[a][y].moznosti->x[i] = a - 1;
		pole[a][y].moznosti->y[i] = b + 2;
		i++;
	}
	if (a - 2 >= 0 && b + 1 <= n) {
		pole[a][y].moznosti->x[i] = a - 2;
		pole[a][y].moznosti->y[i] = b + 1;
		i++;
	}
//tret� kvadrant
	if (a - 2 >= 0 && b - 1 >= 0) {
		pole[a][y].moznosti->x[i] = a - 2;
		pole[a][y].moznosti->y[i] = b - 1;
		i++;
	}
	if (a - 1 >= 0 && b - 2 >= 0) {
		pole[a][y].moznosti->x[i] = a - 1;
		pole[a][y].moznosti->y[i] = b - 2;
		i++;
	}
//�tvrt� kvadrant
	if (a + 1 <= n && b - 2 >= 0) {
		pole[a][y].moznosti->x[i] = a + 1;
		pole[a][y].moznosti->y[i] = b - 2;
		i++;
	}
	if (a + 2 <= n && b - 1 >= 0) {
		pole[a][y].moznosti->x[i] = a + 2;
		pole[a][y].moznosti->y[i] = b - 1;
		i++;
	}

	pole[x][y].pocet= i;
	return;
}

void vypis(){

	for (int i = 0; i < n; i++) {

			for(int j=0;j<n;j++){
			printf("%d - ",pole[i][j].poradie);

			}
			printf("\n");
		}

	return;
}


int posun_o_moznost (){

	int i=1;

	while(i<=pole[x][y].pocet){

		if(pole[pole[x][y].moznosti->x[i]][pole[x][y].moznosti->y[i]].poradie == 0 && pole[x][y].moznosti->skusil[i]==0){
			pole[x][y].moznosti->skusil[i]=1;
			break;
		}
		i++;

	}
	if(i>pole[x][y].pocet){
		return 0;
	}


	pole[pole[x][y].moznosti->x[i]][pole[x][y].moznosti->y[i]].poradie = cislo;
	cislo++;

	x =	pole[x][y].moznosti->x[i];
	y = pole[x][y].moznosti->y[i];

	return 1;
}

void navrat(){
	cislo--;

	int x1=0,y1=0;
	int k=0;


	for(int a=0;a<n;a++){
		for(int b=0;b<n;b++){
			if(pole[a][b].poradie==cislo){
				x1=a;
				y1=b;
				break;
			}
		}

	}

//	printf("%d    %d \n",x1,y1);

	for(int l=0;l < pole[x1][y1].pocet;l++){
		if(pole[x1][y1].moznosti->x[l]==x && pole[x1][y1].moznosti->y[l]== y){
			k=l;
			break;
		}
	}


	pole[x1][y1].moznosti->skusil[k]=1;

	x=x1;
	y=y1;

	return;
}

void napreduj() {

	int pocitadlo = 0;
	int s = 0;
	while (cislo != (n * n) || pocitadlo != 1000) {

		printf("%d cislo %d  %d  posuny \n",pocitadlo,x,y);

		s = posun_o_moznost();
		if (s == 0) {
			navrat();
		}

	}

	vypis();

}




int main() {



	pole = (bunka**) malloc(n * sizeof(bunka));
	for (int i = 0; i < n; i++) {
		pole[i] = (bunka*) malloc(n * sizeof(bunka));
		for(int j=0;j<n;j++){
		pole[i][j].poradie =0;
		najdi_susedov(i,j);
		}
	}

	vypis();

	pole[x][y].poradie =1;
	printf("ahoj");
	napreduj();
  
	printf("ahoj");

  
  return 0;
}
