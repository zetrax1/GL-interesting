/*
 * autor - Vladim�r Ve�erek
 * n�zov -projekt_1_5.c
 * verzia -1.5 A
 * d�tum -2017
 */

#include <stdio.h>
#include <string.h>

struct blok {

	void* pointer_v_za;
	struct blok *pointer_b_za;
	struct blok *pointer_b_pred;
};
typedef struct blok blok;

struct vlastnosti_pola {
	unsigned int celkova_kapacita;
	void *najb_volny_pointer;
	void *najb_obsadeny_za_pointer;
	struct blok *naj_k_v_pred_blok;
	struct blok *prvy_blok;

};
typedef struct vlastnosti_pola pole;

struct male_pole {
	unsigned int celkova_kapacita;
	struct v_blok* prvy_b;
	struct mini* prve_mini;
};
typedef struct male_pole mpole;

struct v_blok {
	struct v_blok* v_blok_za;
	struct v_blok* v_blok_pred;
	char b_velkost;
};
typedef struct v_blok v_blok;

struct o_blok {
	char velkost;
};
typedef struct o_blok o_blok;

void *Zaciatok;

void* najblizsi_volny(unsigned int velkost) {

	struct vlastnosti_pola* tmp = (struct vlastnosti_pola*) Zaciatok;
//pr�pad B prve miesto ak je dostatocne velke

	if (tmp->najb_obsadeny_za_pointer
			== (void*) (tmp->celkova_kapacita + (int) Zaciatok)) {
		if ((int) tmp->najb_obsadeny_za_pointer - (int) tmp->najb_volny_pointer
				> velkost + sizeof(blok)) {
			return tmp->najb_volny_pointer;
		} else {
			return NULL;
		}

	} else {

//Pr�pad C
		void* volny = tmp->najb_volny_pointer;

		while ((int) tmp->naj_k_v_pred_blok > (int) tmp->najb_volny_pointer) {
			tmp->naj_k_v_pred_blok = tmp->naj_k_v_pred_blok->pointer_b_pred;
			if (tmp->naj_k_v_pred_blok == tmp->prvy_blok) {
				tmp->naj_k_v_pred_blok = NULL;
				break;
			}
		}

		int rataj;

		if (tmp->naj_k_v_pred_blok == NULL) {

			rataj = ((int) tmp->prvy_blok - sizeof(struct blok) - (int) volny);
			if (rataj < 0 || rataj < velkost) {
				volny = tmp->prvy_blok->pointer_v_za;
				tmp->naj_k_v_pred_blok = tmp->prvy_blok;
				if (tmp->naj_k_v_pred_blok->pointer_b_za == NULL) {
					if (((tmp->celkova_kapacita + (int) Zaciatok) - (int) volny)
							>= (velkost + sizeof(struct blok))) {
						return volny;
					} else {
						return NULL;
					}

				}

				while (tmp->naj_k_v_pred_blok->pointer_v_za
						== tmp->naj_k_v_pred_blok->pointer_b_za->pointer_v_za) {

					tmp->naj_k_v_pred_blok =
							tmp->naj_k_v_pred_blok->pointer_b_za;

					if (((tmp->celkova_kapacita + (int) Zaciatok) - (int) volny)
							>= (velkost + sizeof(struct blok))) {
						return volny;
					} else {
						return NULL;
					}

				}

			} else {
				return volny;
			}

		} else {

			rataj = ((int) tmp->naj_k_v_pred_blok->pointer_b_za
					- sizeof(struct blok) - (int) volny);
		}

		while (rataj < 0 || rataj < velkost) {

// urcime si dalsi volny blok pre ktor� vyr�tame velkost;
			if (tmp->naj_k_v_pred_blok->pointer_b_za == NULL) {

				if (((tmp->celkova_kapacita + (int) Zaciatok) - (int) volny)
						>= (velkost + sizeof(struct blok))) {
					return volny;
				} else {
					return NULL;
				}

			}

			volny = tmp->naj_k_v_pred_blok->pointer_b_za->pointer_v_za;

//hladame najblizsi volny blok pred
			while ((int) tmp->naj_k_v_pred_blok->pointer_b_za < (int) volny) {

				tmp->naj_k_v_pred_blok = tmp->naj_k_v_pred_blok->pointer_b_za;

				if (tmp->naj_k_v_pred_blok->pointer_b_za == NULL) {

					if (((tmp->celkova_kapacita + (int) Zaciatok) - (int) volny)
							>= (velkost + sizeof(struct blok))) {
						return volny;
					} else {

						while ((int) tmp->naj_k_v_pred_blok
								> (int) tmp->najb_volny_pointer) {
							tmp->naj_k_v_pred_blok =
									tmp->naj_k_v_pred_blok->pointer_b_pred;
							if (tmp->naj_k_v_pred_blok == tmp->prvy_blok) {
								tmp->naj_k_v_pred_blok = NULL;
							}

						}

						return NULL;
					}
				}
			}

			rataj = ((int) tmp->naj_k_v_pred_blok->pointer_b_za
					- sizeof(struct blok) - (int) volny);
			if (tmp->naj_k_v_pred_blok->pointer_b_za->pointer_v_za == NULL) {
				return NULL;
			}

		}
		return volny;
	}

}

v_blok* najdi_vhodny_volny(unsigned int velkost) {

	struct male_pole* tmp = (struct male_pole*) Zaciatok;

	struct v_blok* pom = tmp->prvy_b;

	while (pom->b_velkost >= velkost + sizeof(o_blok)) {
		pom = pom->v_blok_za;
		if (pom == NULL) {
			if (pom->b_velkost < velkost + sizeof(o_blok)) {
				return NULL;
			} else
				return pom;
		}
	}
	return pom;

}

void *memory_alloc(unsigned int size) {

//	struct male_pole* tmp = (struct male_pole*) Zaciatok;
// Varianta pre velk� mnozstvo pam�te , nebere ohlad na pam�t sk�r na jednoduch� dealokovanie , uchov�va viacej
//informacii o jednotliv�ch allocovan�ch blokoch pam�te
//	if (tmp->celkova_kapacita > 65551) {

	struct vlastnosti_pola* tmp = (struct vlastnosti_pola*) Zaciatok;

//pr�pad A ked tvorime prvy prvok pola
	if (tmp->prvy_blok == NULL) {

		if (size < (tmp->celkova_kapacita - sizeof(pole))) {

			struct blok* novy = (struct blok*) tmp->najb_volny_pointer;

			novy->pointer_v_za = (void*) ((int) tmp->najb_volny_pointer
					+ sizeof(blok) + size);
			novy->pointer_b_pred = NULL;
			novy->pointer_b_za = NULL;
			tmp->prvy_blok = novy;
			tmp->prvy_blok->pointer_b_pred = NULL;
			tmp->naj_k_v_pred_blok = tmp->prvy_blok;
			tmp->najb_volny_pointer = novy->pointer_v_za;

			return (void*) ((int) tmp->prvy_blok + sizeof(blok));

		} else {
			return NULL;

		}
	} else {
// �al�ie pr�pady ked doplnyme do pola

		void* pom = najblizsi_volny(size);

		if (pom == NULL) {
			return NULL;
		}
		struct blok* novy = (struct blok*) pom;
		novy->pointer_b_pred = tmp->naj_k_v_pred_blok;

//poprepajanie noveho bloku z ostatn�mi  a ur�enie volneho za nim ;
		if (tmp->naj_k_v_pred_blok == NULL) {
			novy->pointer_b_pred = NULL;
			novy->pointer_b_za = tmp->prvy_blok;
			if (size == ((int) tmp->prvy_blok - (int) pom)) {
				novy->pointer_v_za = tmp->prvy_blok->pointer_v_za;
			} else {
				novy->pointer_v_za = (void*) ((int) novy + sizeof(blok) + size);
			}
			tmp->prvy_blok = novy;
		} else {

			if (tmp->naj_k_v_pred_blok->pointer_b_za == NULL) {
				novy->pointer_b_pred->pointer_b_za = novy;
				novy->pointer_b_za = NULL;
				novy->pointer_v_za = (void*) ((int) novy + sizeof(blok) + size);

			} else {
				novy->pointer_b_za = tmp->naj_k_v_pred_blok->pointer_b_za;
				novy->pointer_b_pred->pointer_b_za = novy;
				novy->pointer_b_za->pointer_b_pred = novy;

				if ((int) novy->pointer_b_za - (int) novy + sizeof(blok)
						== size) {
					novy->pointer_v_za = novy->pointer_b_pred->pointer_v_za;
				} else {
					novy->pointer_v_za = (void*) ((int) novy + sizeof(blok)
							+ size);
				}

			}
		}

//aktualizovanie predo�l�ch pol�

		struct blok* hilfe = novy;

		if (hilfe->pointer_b_pred != NULL) {

			while ((int) hilfe->pointer_b_pred->pointer_v_za == (int) pom) {
				hilfe->pointer_b_pred->pointer_v_za = novy->pointer_v_za;

				hilfe = hilfe->pointer_b_pred;

				if (hilfe == tmp->prvy_blok) {
					break;
				}

			}
		}

// podmienka na skr�tenie �asu ak uklad�me na koniec uzavret�ho bloku od zaciatku
		if ((int) novy->pointer_v_za == (int) tmp->prvy_blok->pointer_v_za) {

			tmp->naj_k_v_pred_blok = novy;
			tmp->najb_volny_pointer = novy->pointer_v_za;
			if (novy->pointer_b_za != NULL) {
				tmp->najb_obsadeny_za_pointer =
						(void*) ((int) novy->pointer_b_za + sizeof(blok));
			} else {
				tmp->najb_obsadeny_za_pointer = (void*) (tmp->celkova_kapacita
						+ (int) Zaciatok);
			}

			return (void*) ((int) novy + sizeof(blok));
		}

//aktualizovanie pola , aktualizovanie najbliz�ieho volneho pointre , najbli��ieho obsadeneho bloku pred n�m .

		tmp->najb_volny_pointer = tmp->prvy_blok->pointer_v_za;
		tmp->naj_k_v_pred_blok = tmp->prvy_blok;

		while (tmp->naj_k_v_pred_blok->pointer_v_za == tmp->najb_volny_pointer) {
			if (tmp->naj_k_v_pred_blok->pointer_b_za == NULL) {
				break;
			}
			tmp->naj_k_v_pred_blok = tmp->naj_k_v_pred_blok->pointer_b_za;
		}

		return (void*) ((int) novy + sizeof(blok));

	}
//	}
// Varianta ked je mno�stvo pam�te obmedzen� a je potrebn� vyu�it ka�d� bajt....
//	T�to varianta je v�ak obmedzena  velkostov typu char  teda  jeden allokovany kus pam�te je maximalne velky 65 535b
	/*	else {

	 struct male_pole* tmp = (struct male_pole*) Zaciatok;
	 void* tmp_blok;
	 void* inf_blok;
	 //Varianta A_1 pre male pole
	 if (tmp->prvy_b
	 == (struct v_blok*) ((int) Zaciatok + sizeof(struct male_pole))) {
	 if (size > tmp->celkova_kapacita - sizeof(mpole)) {
	 return NULL;
	 }

	 tmp_blok = (void*) ((int) Zaciatok + sizeof(struct male_pole)
	 + sizeof(o_blok) + size);
	 struct v_blok* novy = (struct v_blok*) tmp_blok;
	 tmp->prvy_b = novy;
	 novy->b_velkost = (tmp->celkova_kapacita - (int) novy
	 + sizeof(v_blok));
	 novy->v_blok_pred = NULL;
	 novy->v_blok_za = NULL;
	 inf_blok = (void*) ((int) Zaciatok + sizeof(struct male_pole));
	 struct o_blok* inf = (struct o_blok*) inf_blok;
	 inf->velkost = (char) size;
	 }
	 //varianta B_1
	 else {
	 v_blok* pom;


	 pom = najdi_vhodny_volny(size + sizeof(v_blok));

	 if (pom == NULL) {
	 return NULL;
	 }
	 tmp_blok = (void*) ((int) pom + sizeof(o_blok) + size);
	 struct v_blok* novy = (struct v_blok*) tmp_blok;

	 novy->v_blok_pred = pom->v_blok_pred;
	 novy->v_blok_za = pom->v_blok_za;
	 inf_blok = (void*) pom;
	 struct o_blok* inf = (struct o_blok*) inf_blok;
	 inf->velkost = (char) size;


	 }

	 return inf_blok;
	 }*/
}

int memory_free(void *valid_ptr) {

	struct vlastnosti_pola* tmp = (struct vlastnosti_pola*) Zaciatok;
	struct blok* pom = (struct blok*) ((int) valid_ptr - sizeof(struct blok));

	struct blok* hilfe;

// pr�pad A - uvolnujeme prve pole prvku :
	if ((int) pom == tmp->prvy_blok) {

		tmp->naj_k_v_pred_blok = NULL;

		if (tmp->prvy_blok->pointer_b_za == NULL) {
			tmp->prvy_blok = NULL;
			tmp->najb_volny_pointer = (void*) ((int) Zaciatok
					+ sizeof(struct vlastnosti_pola));
			tmp->najb_obsadeny_za_pointer = (void*) (tmp->celkova_kapacita
					+ (int) Zaciatok);
			return 0;
		} else {
			tmp->prvy_blok = pom->pointer_b_za;
			tmp->naj_k_v_pred_blok = NULL;
			tmp->najb_obsadeny_za_pointer = (void*) ((int) tmp->prvy_blok
					+ sizeof(struct blok));
			tmp->najb_volny_pointer = (void*) ((int) Zaciatok
					+ sizeof(struct vlastnosti_pola));
			return 0;
		}

	}

//pripad B ked uvolnujeme v strede

	if (pom->pointer_b_za != NULL) {
		pom->pointer_b_pred->pointer_b_za = pom->pointer_b_za;
		pom->pointer_b_za->pointer_b_pred = pom->pointer_b_pred;
	}

	if (pom->pointer_b_za == NULL) {
		pom->pointer_b_pred->pointer_b_za = NULL;

	}

	if (pom->pointer_b_pred->pointer_v_za == pom->pointer_v_za) {
		hilfe = pom;
		while (hilfe->pointer_b_pred->pointer_v_za == pom->pointer_v_za) {

			hilfe->pointer_b_pred->pointer_v_za = (void*) pom;
			hilfe = hilfe->pointer_b_pred;

			if ((int) hilfe == (int) tmp->prvy_blok) {
				hilfe->pointer_v_za = (void*) pom;
				if ((int) tmp->najb_volny_pointer > (int) hilfe->pointer_v_za) {
					tmp->najb_volny_pointer = (void*) pom;
					tmp->najb_obsadeny_za_pointer =
							(void*) ((int) pom->pointer_b_za
									+ sizeof(struct blok));
					tmp->naj_k_v_pred_blok = pom->pointer_b_pred;
				}
				return 0;
			}
		}
	}

	return 0;
}

int memory_check(void *ptr) {

	struct vlastnosti_pola* tmp = (struct vlastnosti_pola*) Zaciatok;
	struct blok* pom = tmp->prvy_blok;

	if ((int) ptr
			> ((int) Zaciatok + tmp->celkova_kapacita)|| (int)ptr <(int)Zaciatok || tmp->prvy_blok == NULL) {
		return 0;
	}

	if ((int) ptr
			> (int) tmp->najb_volny_pointer&& tmp->naj_k_v_pred_blok != NULL) {
		pom = tmp->naj_k_v_pred_blok;
	}

	while ((int) pom < (int) ptr) {

		if ((int) ptr == ((int) pom + sizeof(struct blok))) {
			return 1;
		}
		if (pom->pointer_b_za == NULL) {
			return 0;
		}

		pom = pom->pointer_b_za;
	}

	return 0;
}

void memory_init(void *ptr, unsigned int size) {

	Zaciatok = ptr;
//Varianta pre velke polia kde je dostatok miesta ide v�ak o r�chlos�
//	if (size > 65551) {
	struct vlastnosti_pola* tmp = (struct vlastnosti_pola*) Zaciatok;
	tmp->celkova_kapacita = size;
	tmp->najb_volny_pointer = (void*) ((int) Zaciatok
			+ sizeof(struct vlastnosti_pola));
	tmp->najb_obsadeny_za_pointer = (void*) (size + (int) Zaciatok);
	tmp->naj_k_v_pred_blok = NULL;
	tmp->prvy_blok = NULL;
//Varianta pre male pole
	/*
	 } else {

	 struct male_pole* tmp = (struct male_pole*) Zaciatok;
	 tmp->celkova_kapacita = size;
	 tmp->prvy_b = (struct v_blok*) ((int) Zaciatok
	 + sizeof(struct male_pole));

	 }
	 */

}

int main() {

	char region[100];
	memory_init(region, 100);

	struct vlastnosti_pola* tmp = (struct vlastnosti_pola*) Zaciatok;

	printf("pointer na prve miesto %d \n", (int) tmp->najb_volny_pointer);
	printf("pointer na posledne miesto %d\n",
			(int) tmp->najb_obsadeny_za_pointer);

	void* over = memory_alloc(10);
	void* over1 = memory_alloc(10);
	void* over2 = memory_alloc(10);

	memory_free(over);

//	memory_free(over2);

//	memory_free(over1);

	void* over3 = memory_alloc(10);
	void* over4 = memory_alloc(10);

	void* over13 = memory_alloc(10);
	void* over14 = memory_alloc(10);
//	memory_free(over13);
//	memory_free(over14);
	void* over15 = memory_alloc(10);
	void* over16 = memory_alloc(10);
//	memory_free(over4);
	void* over17 = memory_alloc(10);

	void* over18 = memory_alloc(12);

//	memory_free(over17);
	void* over22 = memory_alloc(8);
	void* over23 = memory_alloc(13);

	printf(" %d\n %d \n \n", (int) over, (int) over1);
	printf(" %d\n %d \n \n", (int) over2, (int) over3);
	printf(" %d\n %d \n \n", (int) over4, (int) over13);
	printf(" %d\n %d \n \n", (int) over14, (int) over15);
	printf(" %d\n %d \n \n", (int) over16, (int) over17);

	return 0;
}
