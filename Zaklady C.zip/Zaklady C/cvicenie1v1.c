/*
 * autor - Vladim�r Ve�erek
 * n�zov -uloha5.1
 * verzia -1
 * d�tum -2017
 */

#include<stdio.h>
#include<stdlib.h>

int modulo = 1;

struct blok {
	int cislo;
	struct blok* dalsi;

};
typedef struct blok blok;

int f_hash(int tmp) {

	int pozicia = 0;
	pozicia = (tmp + (modulo * tmp + 17) * 23) % modulo;
	return pozicia;
}

int is_subset(int s[], int n, int t[], int m) {

	int pozicia;
	modulo = m;
	struct blok Pole[modulo];

	for (int i = 0; i < modulo; i++) {
		Pole[i].cislo = 0;
		Pole[i].dalsi = NULL;
	}

	for (int i = 0; i < m; i++) {
		pozicia = f_hash(t[i]);
		int deb = t[i];
		blok *tmp ,*help;

		if (Pole[pozicia].cislo == 0) {
			Pole[pozicia].cislo = t[i];

		} else {
			tmp = (blok*) malloc(sizeof(struct blok));
			if(Pole[pozicia].dalsi == NULL){
				Pole[pozicia].dalsi = tmp;
			}else{
				help =Pole[pozicia].dalsi;
				tmp = help;

				while (help != NULL) {
				tmp = help;
				help = help->dalsi;
			}

			}


			tmp->cislo = t[i];
			tmp->dalsi = NULL;

		}

	}

	for (int j = 0; j < n; j++) {
		int najdi;
		int debag = s[j];

		blok *vymaz, *val, *pred;
		najdi = f_hash(s[j]);
		val = Pole[najdi].dalsi;

		if (s[j] != Pole[najdi].cislo) {

			if ((Pole[najdi].cislo != s[j]) && (Pole[najdi].dalsi == NULL)) {
				return 0;
			}

			while (val != NULL) {
				if (val->cislo == s[j]) {


					if(val == Pole[najdi].dalsi){
						vymaz =val;
						Pole[najdi].dalsi = val->dalsi;
						free(vymaz);
					}else{
					vymaz =val;
					pred->dalsi = val->dalsi;
					free(vymaz);
					}


					break;
				}

				if ((val->cislo != s[j]) && (val->dalsi == NULL)) {
					return 0;
				}
				pred = val;
				val = val->dalsi;
			}

		} else {
			if (Pole[najdi].dalsi == NULL) {
				Pole[najdi].cislo = 0;
			} else {

				Pole[najdi].cislo = Pole[najdi].dalsi->cislo;
				vymaz = Pole[najdi].dalsi;
				Pole[najdi].dalsi = Pole[najdi].dalsi->dalsi;
				free(vymaz);

			}

		}

	}

	blok *uprac,*neupratany ;
	for (int i = 0; i < modulo; i++) {
		neupratany = Pole[i].dalsi;
		if (Pole[i].dalsi != NULL) {

			uprac = Pole[i].dalsi;
			while (uprac != NULL) {
				neupratany = uprac;
				uprac = uprac->dalsi;
			}
			neupratany->dalsi = NULL;
			free(uprac);

			while (neupratany != Pole[i].dalsi) {

				uprac = Pole[i].dalsi;
				while (uprac != NULL) {
					neupratany = uprac;
					uprac = uprac->dalsi;
				}
				neupratany->dalsi = NULL;
				free(uprac);

			}
			free(neupratany);

		}
	}

	return 1;
}

int main() {
	int S_mnozina[] = { 49 ,86, 62, 93, 92, 86, 92, 15, 92, 77 };
	int T_mnozina[] = { 86 ,77 ,15 ,93 ,35 ,86 ,92 ,49 ,21 ,62};
	int a = 10, b = 10;

	if (is_subset(S_mnozina, a, T_mnozina, b)) {
		printf("PODMNOZINA\n");
	} else {
		printf("NIE\n");
	}

	return 0;
}
