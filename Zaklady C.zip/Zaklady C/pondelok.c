/*
* autor - Vladim�r Ve�erek
* n�zov -pondelok.c
* verzia -
* d�tum -2017
*/

/*
* autor - Vladim�r Ve�erek
* n�zov -verzia1.c
* verzia -
* d�tum -2017
*/

/*
 * autor - Vladim�r Ve�erek
 * n�zov -sobota.c
 * verzia -
 * d�tum -2017
 */

#include<stdio.h>
#include<stdlib.h>

int princezna[3][2];
int drak[2];
int *ptmp;
int pocetN=0;
int N,M,celkom,V=0;
int X=0,Y=0;



struct policko{

	int sur_pred[2];
	int vzdialenost;

};

struct tmpbunka{

	int sur[2];

};

struct tsusedia{
	int existuje[4];
	int vlavo[2];
	int vpravo[2];
	int hore[2];
	int dole[2];

};

typedef struct tmpbunka bunka;
typedef struct policko policko;
typedef struct tsusedia susedia;

struct policko **pole;
susedia *sused =NULL;
bunka **tmp=NULL;


//v�pis cesty odkial kam
void vypis_cesty(int x,int y,int x2 ,int y2){

int x3;
	while(!(y2 == pole[y][x].sur_pred[1] && x2 == pole[y][x].sur_pred[0])){

		printf("suradnice pred [ %d %d ] su [ %d %d ]  a vzdialenos� od %d %d  je %d \n",x,y,pole[y][x].sur_pred[0],pole[y][x].sur_pred[1],x2,y2,pole[y][x].vzdialenost);
		x3=x;
		x=pole[y][x].sur_pred[0];
		y=pole[y][x3].sur_pred[1];

	}
}
//funkcia prehlada celu mapu a najde potrebn� pol�cka
void najdi_draka_princezne(char **mapa){

	char c;
	int tmp=0;

	for(int i=0;i<N;i++){
		for(int j=0;j<M;j++){
			c=mapa[i][j];

			if(c == 'D'){
				drak[0]=i;
				drak[1]=j;
			}
			if(c=='P'){
				princezna[tmp][1]=i;
				princezna[tmp][0]=j;
				tmp++;

			}
			if(c=='N'){
				pocetN++;
			}

		}


	}


celkom = (M*N) - pocetN - 4;

	return;
}
//funkcia najde suseda k suradniciam x|y
void zisti_susedov(int x,int y ,char **mapa){

	if(sused == NULL){
		sused = (susedia*)malloc(sizeof(susedia));
	}
	sused->existuje[0]=0;
	sused->existuje[1]=0;
	sused->existuje[2]=0;
	sused->existuje[3]=0;

	//existuje  0hore,1dole,2vlavo,3vpravo
	if (x != 0 && mapa[y][x - 1] != 'n') {
		sused->existuje[2] = 1;
		sused->vlavo[0] = x - 1;
		sused->vlavo[1] = y;
	}

	if (x != M - 1 && mapa[y][x + 1] != 'n') {
		sused->existuje[3] = 1;
		sused->vpravo[0] = x + 1;
		sused->vpravo[1] = y;
	}

	if (y != 0 && mapa[y - 1][x] != 'n') {
		sused->existuje[0] = 1;
		sused->hore[0] = x;
		sused->hore[1] = y - 1;
	}
	if (y != N - 1 && mapa[y + 1][x] != 'n') {
		sused->existuje[1] = 1;
		sused->dole[0] = x;
		sused->dole[1] = y + 1;
	}


return;


}
//prida do pola tmp suradnice
void pridaj_do_tmp(int x,int y,int pozicia){



//	int debag2 =ptmp[pozicia];
	ptmp[pozicia]++;
	int i=0;
//	int debag =ptmp[pozicia];
//	tmp[pozicia]= (bunka*)realloc(tmp[pozicia],((ptmp[pozicia]+1)*sizeof(bunka)));

	bunka *pom;
	pom=(bunka*)malloc((ptmp[pozicia]+1)*sizeof(bunka));

	while(i<ptmp[pozicia]){
		pom[i].sur[0]=tmp[pozicia][i].sur[0];
		pom[i].sur[1]=tmp[pozicia][i].sur[1];
		i++;
	}

//	free(tmp[pozicia]);

	tmp[pozicia]=pom;

	tmp[pozicia][ptmp[pozicia]-1].sur[0]=x;

	tmp[pozicia][ptmp[pozicia]-1].sur[1]=y;

	return;


}
//odstr�ni spola jeden prvok podla suradnic
void odstran_z_tmp(int x,int y,int pozicia){

	int i=0,j=0;
	bunka *pom;
	pozicia++;
	pozicia=pozicia%3;
	pom=(bunka*)malloc(ptmp[pozicia]*sizeof(bunka));

//neodebagovane pozri sa na to ci to nema byt <	miesto !=
	while(i < ptmp[pozicia]){

		pom[j].sur[0]=tmp[pozicia][i].sur[0];
		pom[j].sur[1]=tmp[pozicia][i].sur[1];
		i++;
		j++;
		if(tmp[pozicia][i].sur[1] == y && tmp[pozicia][i].sur[0] == x){
			i++;

		}


	}

//	free(tmp[pozicia]);
	tmp[pozicia]=pom;
	ptmp[pozicia]--;





}
//funkcia aktualizuje susedov daneho prvku :D
void aktualizuj(int x ,int y,char **mapa){

	//existuje = 0hore,1dole,2vlavo,3vpravo
	int cena ,hodnota;
	zisti_susedov(x, y, mapa);


	if(mapa[y][x] == 'H'){
		cena =2;
	}else{
		cena =1;
	}
	hodnota =pole[y][x].vzdialenost;

	int pozicia =(hodnota+cena)%3;


	// podmienka na suseda hore
	if(sused->existuje[0] ==1 && (pole[sused->hore[1]][sused->hore[0]].vzdialenost ==0 || pole[sused->hore[1]][sused->hore[0]].vzdialenost > hodnota+cena)&& !(sused->hore[0] == X && sused->hore[1] == Y)){
		if(pole[sused->hore[1]][sused->hore[0]].vzdialenost !=0 && ptmp[(pozicia+1)%3]!=1){
			odstran_z_tmp(sused->hore[0],sused->hore[1], pozicia);
		}
		if( ptmp[(pozicia+1)%3]==1 && pole[sused->hore[1]][sused->hore[0]].vzdialenost !=0){
			 ptmp[(pozicia+1)%3]--;
		}

		pridaj_do_tmp(sused->hore[0],sused->hore[1], pozicia);
		pole[sused->hore[1]][sused->hore[0]].vzdialenost = hodnota+cena;
		pole[sused->hore[1]][sused->hore[0]].sur_pred[0]=x;
		pole[sused->hore[1]][sused->hore[0]].sur_pred[1]=y;


	}
	//dole
	if(sused->existuje[1] ==1 && (pole[sused->dole[1]][sused->dole[0]].vzdialenost ==0 || pole[sused->dole[1]][sused->dole[0]].vzdialenost > hodnota+cena)&& !(sused->dole[0] == X && sused->dole[1] == Y)){
		if (pole[sused->dole[1]][sused->dole[0]].vzdialenost != 0 &&  ptmp[(pozicia+1)%3]!=1) {
			odstran_z_tmp(sused->dole[0], sused->dole[1], pozicia);
		}
		if( ptmp[(pozicia+1)%3]==1 && pole[sused->dole[1]][sused->dole[0]].vzdialenost != 0 ){
					 ptmp[(pozicia+1)%3]--;
		}

		pridaj_do_tmp(sused->dole[0], sused->dole[1], pozicia);
		pole[sused->dole[1]][sused->dole[0]].vzdialenost = hodnota+cena;
		pole[sused->dole[1]][sused->dole[0]].sur_pred[0]=x;
		pole[sused->dole[1]][sused->dole[0]].sur_pred[1]=y;
	}
	//vlavo
	if(sused->existuje[2] ==1 && (pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost ==0 || pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost > hodnota+cena) && !(sused->vlavo[0] == X && sused->vlavo[1] == Y)){
		if (pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost != 0 &&  ptmp[(pozicia+1)%3]!=1) {
			odstran_z_tmp(sused->vlavo[0], sused->vlavo[1], pozicia);
		}
		if( ptmp[(pozicia+1)%3]==1 && pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost != 0){
					 ptmp[(pozicia+1)%3]--;
				}

		pridaj_do_tmp(sused->vlavo[0], sused->vlavo[1], pozicia);
		pole[sused->vlavo[1]][sused->vlavo[0]].vzdialenost = hodnota+cena;
		pole[sused->vlavo[1]][sused->vlavo[0]].sur_pred[0]=x;
		pole[sused->vlavo[1]][sused->vlavo[0]].sur_pred[1]=y;
	}
	//vpravo
	if(sused->existuje[3] ==1 && (pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost ==0 || pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost > hodnota+cena)&& !(sused->vpravo[0] == X && sused->vpravo[1] == Y)){
		if (pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost != 0 &&  ptmp[(pozicia+1)%3]!=1) {
			odstran_z_tmp(sused->vpravo[0], sused->vpravo[1], pozicia);
		}
		if( ptmp[(pozicia+1)%3]==1 && pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost != 0){
					 ptmp[(pozicia+1)%3]--;
			}
		int debagx=sused->vpravo[0],debagy = sused->vpravo[1];
		pridaj_do_tmp(sused->vpravo[0], sused->vpravo[1], pozicia);
		pole[sused->vpravo[1]][sused->vpravo[0]].vzdialenost = hodnota+cena;
		pole[sused->vpravo[1]][sused->vpravo[0]].sur_pred[0]=x;
		pole[sused->vpravo[1]][sused->vpravo[0]].sur_pred[1]=y;


	}

}
//funkcia zist� najkrat�iu cestu od danej suradnice :D
void zisti_cestu_od(int x,int y ,char **mapa){

//malloc nov�ho pomocn�ho pola velkost 3*1

	tmp = (struct tmpbunka**) malloc(3 * sizeof(struct tmpbunka));
	for (int i = 0; i < 3; i++) {
		tmp[i] = (struct tmpbunka*) malloc(1 * sizeof(struct tmpbunka));
	}

	ptmp =(int*)malloc(3*sizeof(int));
	ptmp[0]=0;
	ptmp[1]=0;
	ptmp[2]=0;



//zap�sanie si v�chodiskov�ho bodu

	pole[y][x].vzdialenost = 0;
	int i=0;
	int hodnota = 0;
	int preklop=1;
	X=x;
	Y=y;


	aktualizuj(x, y, mapa);


int pa=0;


	while(i != celkom){
		i++;


		for(int j=0;j<ptmp[preklop];j++){

		//	printf (" %d prave sa aktualizuju suradnice  [%d %d] \n",pa,tmp[preklop][j].sur[0],tmp[preklop][j].sur[1] );
		//	printf("%d %d %d  \n",pa, pole[tmp[preklop][j].sur[1]][tmp[preklop][j].sur[0]].sur_pred[0], pole[tmp[preklop][j].sur[1]][tmp[preklop][j].sur[0]].sur_pred[1]);
			aktualizuj(tmp[preklop][j].sur[0], tmp[preklop][j].sur[1], mapa);
			pa++;


		}

	//	free(tmp[preklop]);
		tmp[preklop] = (struct tmpbunka*) malloc(1 * sizeof(struct tmpbunka));
		ptmp[preklop]=0;

		preklop++;
		preklop=preklop%3;



	}










}


int *konvertni(int x,int y , int x2 ,int y2){

	int *cesticka,*vratena;
	int vel=2;
	int x4=x,y4=y;

	cesticka = (int*)malloc(sizeof(int));

	int x3;
		while(!(y2 == pole[y][x].sur_pred[1] && x2 == pole[y][x].sur_pred[0])){
			x3=x;
			x=pole[y][x].sur_pred[0];
			y=pole[y][x3].sur_pred[1];

			cesticka=(int*)realloc(cesticka,(sizeof(int)*vel));
			cesticka[vel-1]=x;
			cesticka[vel-2]=y;
		//	printf("%d %d  \n",x,y);
		//	printf("%d %d \n \n",cesticka[vel-2],cesticka[vel-1]);
			vel=vel+2;
		}
		V=vel;

		vratena = (int*)malloc((vel+2)*sizeof(int));
		for(int j=0;j<vel-2;j++){
			vratena[j]=cesticka[vel-3-j];
		}

		vratena[vel-2]= x4;
		vratena[vel-1]= y4;


		free(cesticka);


	return vratena;
}

void vycisti(){

	for (int i = 0; i < N; i++) {
			for(int j=0;j<M;j++){
			pole[i][j].vzdialenost =0;
			}
		}
	free(ptmp);
	for(int j=0;j<3;j++){
		free(tmp[j]);
	}
	free(tmp);

	return;
}

void vypis_mapu(int n ,int m,char **mapa){

	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
//printf("mapa[%d][%d]='%c'; \n ",i,j,mapa[i][j]);
	printf("%c",mapa[i][j]);
		}
		printf("\n");


	}
	printf("\n");
	return;
}

int *zachran_princezne(char **mapa, int n, int m, int t, int *dlzka_cesty) {


//	vypis_mapu(n, m, mapa);
	N=n;
	M=m;
	najdi_draka_princezne(mapa);
	int x=0;
	int y=0;
	X=0;
	Y=0;
	int *vrat,*celkova_cesta,a=0;
	int d_zd=0,d_dp=0,d_pp=0,d_pk=0,dlzkaA,dlzkaB,dlzkaC,dlzkaD,dlzkaE,dlzkaF;
	int poledlzok[6];

	pole = (struct policko**) malloc(n * sizeof(struct policko));
	for (int i = 0; i < n; i++) {
		pole[i] = (struct policko*) malloc(m * sizeof(struct policko));
		for(int j=0;j<m;j++){
		pole[i][j].vzdialenost =0;
		}
	}



	zisti_cestu_od(x, y, mapa);
	vrat = konvertni(drak[1],drak[0], 0, 0);
	d_zd=V+2;
	V=0;

	celkova_cesta = (int*)malloc(d_zd*sizeof(int));
	 celkova_cesta[0]=0;
		celkova_cesta[1]=0;

	for(int k=2;k<d_zd;k++){
		celkova_cesta[k]=vrat[k-2];
	}

	free(vrat);

/*	for (int i=0;i<(d_zd/2);++i){
		 printf("%d %d\n", celkova_cesta[i*2], celkova_cesta[i*2+1]);
		} */

//	printf("%d vel \n",V);






// tak�e m�me celkom viac mo�nost� ako po zabit� draka zachr�ni� princezn� :D
	// po  prv� bez teleportu :D a bez z�le�ania ako dlho n�m to potv� :D ...
		// cesta drak princezna


/*

	vycisti();
	zisti_cestu_od(drak[1], drak[0], mapa);
	vrat = konvertni(princezna[0][0], princezna[0][1], drak[1], drak[0]);
	d_dp = V;
	V = 0;

	celkova_cesta = (int*) realloc(celkova_cesta,
			((d_dp + d_zd) * sizeof(int)));
	for (int k = d_zd; k < (d_zd + d_dp); k++) {
		celkova_cesta[k] = vrat[a];
		a++;
	}
	free(vrat);

	for (int i=0;i<((d_zd+d_dp)/2);++i){
			 printf("  %d %d\n", celkova_cesta[i*2], celkova_cesta[i*2+1]);
			}

	printf("%d .... %d \n",d_dp,d_zd);


	//cesta princezna princezna
	vycisti();
	zisti_cestu_od(princezna[0][0], princezna[0][1], mapa);
	vrat = konvertni(princezna[1][0], princezna[1][1], princezna[0][0], princezna[0][1]);
	d_pp = V;
	V = 0;
	a=0;

	celkova_cesta = (int*) realloc(celkova_cesta,
			((d_dp + d_zd+d_pp) * sizeof(int)));
	for (int k = d_zd+d_dp; k < (d_zd + d_dp+d_pp); k++) {
		celkova_cesta[k] = vrat[a];
		a++;
	}
	free(vrat);



	for (int i=0;i<((d_zd+d_dp+d_pp)/2);++i){

				 printf("  %d %d\n", celkova_cesta[i*2], celkova_cesta[i*2+1]);
				}

	printf("%d .... %d \n",d_pp,d_zd);

	// cesta k poslednej princeznej :D

	vycisti();
	zisti_cestu_od(princezna[1][0], princezna[1][1], mapa);
	vrat = konvertni(princezna[2][0], princezna[2][1], princezna[1][0],
			princezna[1][1]);
	d_pk = V;
	V = 0;
	a = 0;
	for (int i = 0; i < ((d_pk) / 2); ++i) {

		printf("  %d %d\n", vrat[i * 2], vrat[i * 2 + 1]);
	}

	celkova_cesta = (int*) realloc(celkova_cesta,
			((d_dp + d_zd + d_pp + d_pk) * sizeof(int)));
	for (int k = (d_zd + d_dp+d_pp); k < (d_zd + d_dp + d_pp+d_pk); k++) {
		celkova_cesta[k] = vrat[a];
		a++;
	}
	free(vrat);


	for (int k = 0; k < ((d_zd + d_dp + d_pp+d_pk) / 2); k++) {
		printf("%d %d pre \n", celkova_cesta[k * 2],
				celkova_cesta[k * 2 + 1]);
	}


*/



int p1=0,p2=1,p3=2,zdlhava=0,p1o,p2o,p3o;
	// z�chrana princezien v r�znom porad� :
		//  A) princezna 1,2,3

while(zdlhava < 6)	{
		vycisti();
		zisti_cestu_od(drak[1], drak[0], mapa);
		d_pp = pole[princezna[p1][0]][princezna[p1][0]].vzdialenost;
		vycisti();
		zisti_cestu_od(princezna[p1][0], princezna[p1][1], mapa);
		d_dp = pole[princezna[p2][0]][princezna[p2][0]].vzdialenost;
		vycisti();
		zisti_cestu_od(princezna[p2][0], princezna[p2][1], mapa);
		d_pk = pole[princezna[p3][0]][princezna[p3][0]].vzdialenost;

dlzkaA=(d_dp + d_pp+d_pk);

	if(dlzkaA > dlzkaB){
		dlzkaB =dlzkaA;
		dlzkaC =zdlhava;
		p1o=p1;
		p2o=p2;
		p3o=p3;
	}

zdlhava++;
		if (zdlhava == 1) {
			p1 = 0;
			p2 = 2;
			p3 = 1;
		}
		if (zdlhava == 2) {
			p1 = 1;
			p2 = 0;
			p3 = 2;

		}
		if (zdlhava == 3) {
			p1 = 1;
			p2 = 2;
			p3 = 0;
		}
		if (zdlhava == 4) {
			p1 = 2;
			p2 = 0;
			p3 = 1;
		}
		if (zdlhava == 5) {
			p1 = 2;
			p2 = 1;
			p3 = 0;
		}

}



vycisti();
zisti_cestu_od(drak[1], drak[0], mapa);
vrat = konvertni(princezna[p1o][0], princezna[p1o][1], drak[1], drak[0]);
d_dp = V;
V = 0;

celkova_cesta = (int*) realloc(celkova_cesta,
		((d_dp + d_zd) * sizeof(int)));
for (int k = d_zd; k < (d_zd + d_dp); k++) {
	celkova_cesta[k] = vrat[a];
	a++;
}
free(vrat);

/*
for (int i=0;i<((d_zd+d_dp)/2);++i){
		 printf("  %d %d\n", celkova_cesta[i*2], celkova_cesta[i*2+1]);
		}

printf("%d .... %d \n",d_dp,d_zd);
*/


//cesta princezna princezna
vycisti();
zisti_cestu_od(princezna[p1o][0], princezna[p1o][1], mapa);
vrat = konvertni(princezna[p2o][0], princezna[p2o][1], princezna[p1o][0], princezna[p1o][1]);
d_pp = V;
V = 0;
a=0;

celkova_cesta = (int*) realloc(celkova_cesta,
		((d_dp + d_zd+d_pp) * sizeof(int)));
for (int k = d_zd+d_dp; k < (d_zd + d_dp+d_pp); k++) {
	celkova_cesta[k] = vrat[a];
	a++;
}
free(vrat);



/*
for (int i=0;i<((d_zd+d_dp+d_pp)/2);++i){

			 printf("  %d %d\n", celkova_cesta[i*2], celkova_cesta[i*2+1]);
			}

printf("%d .... %d \n",d_pp,d_zd);
*/

// cesta k poslednej princeznej :D

vycisti();
zisti_cestu_od(princezna[p2o][0], princezna[p2o][1], mapa);
vrat = konvertni(princezna[p3o][0], princezna[p3o][1], princezna[p2o][0],
		princezna[p2o][1]);
d_pk = V;
V = 0;
a = 0;
/*for (int i = 0; i < ((d_pk) / 2); ++i) {

	printf("  %d %d\n", vrat[i * 2], vrat[i * 2 + 1]);
}*/

celkova_cesta = (int*) realloc(celkova_cesta,
		((d_dp + d_zd + d_pp + d_pk) * sizeof(int)));
for (int k = (d_zd + d_dp+d_pp); k < (d_zd + d_dp + d_pp+d_pk); k++) {
	celkova_cesta[k] = vrat[a];
	a++;
}
free(vrat);

/*

for (int k = 0; k < ((d_zd + d_dp + d_pp+d_pk) / 2); k++) {
	printf("%d %d pre \n", celkova_cesta[k * 2],
			celkova_cesta[k * 2 + 1]);
}

*/






	*dlzka_cesty=(d_zd + d_dp + d_pp+d_pk)/2;
//	vycisti();



	return celkova_cesta;
}




int main() {


	char **mapa;
	int n = 7, m = 7,d_cesty=0,t=0,*ignor;


/*

	pole[2][1].vzdialenost =1;
	pole[2][1].sur_pred[1]=2;
	pole[2][1].sur_pred[0]=3;
	printf("%d %d %d",pole[2][1].vzdialenost,pole[2][1].sur_pred[0],pole[2][1].sur_pred[1]);
*/




	mapa = (char**) malloc(n * sizeof(char*));
	for (int i = 0; i < n; i++) {
		mapa[i] = (char*) malloc(m * sizeof(char));

	}

	mapa[0][0]='C';
	 mapa[0][1]='C';
	 mapa[0][2]='C';
	 mapa[0][3]='H';
	 mapa[0][4]='H';
	 mapa[0][5]='C';
	 mapa[0][6]='H';

	mapa[1][0]='C';
	 mapa[1][1]='C';
	 mapa[1][2]='H';
	 mapa[1][3]='H';
	 mapa[1][4]='H';
	 mapa[1][5]='C';
	 mapa[1][6]='H';

	mapa[2][0]='H';
	 mapa[2][1]='C';
	 mapa[2][2]='D';
	 mapa[2][3]='C';
	 mapa[2][4]='H';
	 mapa[2][5]='H';
	 mapa[2][6]='C';

	mapa[3][0]='H';
	 mapa[3][1]='H';
	 mapa[3][2]='H';
	 mapa[3][3]='C';
	 mapa[3][4]='H';
	 mapa[3][5]='H';
	 mapa[3][6]='C';

	mapa[4][0]='H';
	 mapa[4][1]='C';
	 mapa[4][2]='H';
	 mapa[4][3]='H';
	 mapa[4][4]='C';
	 mapa[4][5]='C';
	 mapa[4][6]='C';

	mapa[5][0]='H';
	 mapa[5][1]='C';
	 mapa[5][2]='H';
	 mapa[5][3]='H';
	 mapa[5][4]='P';
	 mapa[5][5]='H';
	 mapa[5][6]='H';

	mapa[6][0]='P';
	 mapa[6][1]='C';
	 mapa[6][2]='H';
	 mapa[6][3]='C';
	 mapa[6][4]='H';
	 mapa[6][5]='H';
	 mapa[6][6]='P';

//test 3 mapa
/*
		mapa[0][0] = 'h';
		mapa[0][1] = 'h';
		mapa[0][2] = 'h';
		mapa[0][3] = 'h';
		mapa[0][4] = 'h';
		mapa[0][5] = 'c';
		mapa[0][6] = 'h';
		mapa[0][7] = 'c';
		mapa[0][8] = 'c';
		mapa[0][9] = 'c';
			mapa[0][10] = 'h';
			mapa[0][11] = 'h';
			mapa[0][12] = 'h';
			mapa[0][13] = 'c';
			mapa[0][14] = 'h';
			mapa[0][15] = 'h';
			mapa[0][16] = 'h';
			mapa[0][17] = 'h';
			mapa[0][18] = 'p';
			mapa[0][19] = 'd';
				mapa[0][20] = 'h';
				mapa[0][21] = 'c';
				mapa[0][22] = 'c';
				mapa[0][23] = 'c';
				mapa[0][24] = 'c';
				mapa[0][25] = 'h';
				mapa[0][26] = 'c';
				mapa[0][27] = 'c';
				mapa[0][28] = 'c';
				mapa[0][29] = 'h';


				mapa[1][0] = 'c';
				mapa[1][1] = 'c';
				mapa[1][2] = 'h';
				mapa[1][3] = 'c';
				mapa[1][4] = 'c';
				mapa[1][5] = 'c';
				mapa[1][6] = 'c';
				mapa[1][7] = 'c';
				mapa[1][8] = 'c';
				mapa[1][9] = 'h';
					mapa[1][10] = 'c';
					mapa[1][11] = 'c';
					mapa[1][12] = 'c';
					mapa[1][13] = 'c';
					mapa[1][14] = 'c';
					mapa[1][15] = 'h';
					mapa[1][16] = 'c';
					mapa[1][17] = 'h';
					mapa[1][18] = 'h';
					mapa[1][19] = 'h';
						mapa[1][20] = 'c';
						mapa[1][21] = 'c';
						mapa[1][22] = 'c';
						mapa[1][23] = 'c';
						mapa[1][24] = 'c';
						mapa[1][25] = 'c';
						mapa[1][26] = 'h';
						mapa[1][27] = 'c';
						mapa[1][28] = 'c';
						mapa[1][29] = 'h';


										mapa[2][0] = 'c';
										mapa[2][1] = 'c';
										mapa[2][2] = 'c';
										mapa[2][3] = 'c';
										mapa[2][4] = 'c';
										mapa[2][5] = 'h';
										mapa[2][6] = 'p';
										mapa[2][7] = 'c';
										mapa[2][8] = 'c';
										mapa[2][9] = 'c';
											mapa[2][10] = 'h';
											mapa[2][11] = 'h';
											mapa[2][12] = 'c';
											mapa[2][13] = 'c';
											mapa[2][14] = 'h';
											mapa[2][15] = 'c';
											mapa[2][16] = 'c';
											mapa[2][17] = 'c';
											mapa[2][18] = 'c';
											mapa[2][19] = 'h';
												mapa[2][20] = 'c';
												mapa[2][21] = 'c';
												mapa[2][22] = 'c';
												mapa[2][23] = 'c';
												mapa[2][24] = 'h';
												mapa[2][25] = 'c';
												mapa[2][26] = 'c';
												mapa[2][27] = 'c';
												mapa[2][28] = 'c';
												mapa[2][29] = 'h';

																mapa[3][0] = 'c';
																mapa[3][1] = 'c';
																mapa[3][2] = 'c';
																mapa[3][3] = 'c';
																mapa[3][4] = 'h';
																mapa[3][5] = 'h';
																mapa[3][6] = 'h';
																mapa[3][7] = 'h';
																mapa[3][8] = 'c';
																mapa[3][9] = 'h';
																	mapa[3][10] = 'c';
																	mapa[3][11] = 'c';
																	mapa[3][12] = 'c';
																	mapa[3][13] = 'h';
																	mapa[3][14] = 'c';
																	mapa[3][15] = 'c';
																	mapa[3][16] = 'c';
																	mapa[3][17] = 'c';
																	mapa[3][18] = 'c';
																	mapa[3][19] = 'h';
																		mapa[3][20] = 'c';
																		mapa[3][21] = 'c';
																		mapa[3][22] = 'h';
																		mapa[3][23] = 'c';
																		mapa[3][24] = 'c';
																		mapa[3][25] = 'c';
																		mapa[3][26] = 'c';
																		mapa[3][27] = 'h';
																		mapa[3][28] = 'c';
																		mapa[3][29] = 'h';

																						mapa[4][0] = 'c';
																						mapa[4][1] = 'p';
																						mapa[4][2] = 'h';
																						mapa[4][3] = 'h';
																						mapa[4][4] = 'c';
																						mapa[4][5] = 'c';
																						mapa[4][6] = 'h';
																						mapa[4][7] = 'h';
																						mapa[4][8] = 'c';
																						mapa[4][9] = 'c';
																							mapa[4][10] = 'c';
																							mapa[4][11] = 'h';
																							mapa[4][12] = 'h';
																							mapa[4][13] = 'c';
																							mapa[4][14] = 'h';
																							mapa[4][15] = 'h';
																							mapa[4][16] = 'h';
																							mapa[4][17] = 'c';
																							mapa[4][18] = 'c';
																							mapa[4][19] = 'h';
																								mapa[4][20] = 'c';
																								mapa[4][21] = 'h';
																								mapa[4][22] = 'c';
																								mapa[4][23] = 'h';
																								mapa[4][24] = 'h';
																								mapa[4][25] = 'c';
																								mapa[4][26] = 'c';
																								mapa[4][27] = 'h';
																								mapa[4][28] = 'c';

	*/																							//mapa[4][29] = 'c';
// mapa test 1
/*
	mapa[0][0] = 'p';
	mapa[0][1] = 'p';
	mapa[0][2] = 'h';
	mapa[0][3] = 'h';
	mapa[0][4] = 'h';

	mapa[1][0] = 'h';
	mapa[1][1] = 'c';
	mapa[1][2] = 'h';
	mapa[1][3] = 'h';
	mapa[1][4] = 'c';

	mapa[2][0] = 'c';
	mapa[2][1] = 'c';
	mapa[2][2] = 'h';
	mapa[2][3] = 'c';
	mapa[2][4] = 'c';

	mapa[3][0] = 'c';
	mapa[3][1] = 'h';
	mapa[3][2] = 'c';
	mapa[3][3] = 'h';
	mapa[3][4] = 'c';

	mapa[4][0] = 'h';
	mapa[4][1] = 'p';
	mapa[4][2] = 'c';
	mapa[4][3] = 'd';
	mapa[4][4] = 'c';
*/

//mapa pre moj test
	/*mapa[0][0] = 'c';
	mapa[0][1] = 'c';
	mapa[0][2] = 'h';
	mapa[0][3] = 'h';
	mapa[0][4] = 'c';
	mapa[0][5] = 'c';
	mapa[0][6] = 'h';
	mapa[0][7] = 'c';
	mapa[0][8] = 'h';
	mapa[0][9] = 'c';

	mapa[1][0] = 'n';
	mapa[1][1] = 'c';
	mapa[1][2] = 'c';
	mapa[1][3] = 'c';
	mapa[1][4] = 'c';
	mapa[1][5] = 'g';
	mapa[1][6] = 'n';
	mapa[1][7] = 'c';
	mapa[1][8] = 'n';
	mapa[1][9] = 'c';

	mapa[2][0] = 'n';
	mapa[2][1] = 'h';
	mapa[2][2] = 'h';
	mapa[2][3] = 'n';
	mapa[2][4] = 'n';
	mapa[2][5] = 'n';
	mapa[2][6] = 'n';
	mapa[2][7] = '0';
	mapa[2][8] = 'n';
	mapa[2][9] = 'c';

	mapa[3][0] = 'h';
	mapa[3][1] = 'c';
	mapa[3][2] = 'c';
	mapa[3][3] = 'n';
	mapa[3][4] = 'p';
	mapa[3][5] = 'h';
	mapa[3][6] = 'n';
	mapa[3][7] = 'c';
	mapa[3][8] = 'c';
	mapa[3][9] = 'c';

	mapa[4][0] = 'c';
	mapa[4][1] = 'h';
	mapa[4][2] = 'h';
	mapa[4][3] = '1';
	mapa[4][4] = 'c';
	mapa[4][5] = 'h';
	mapa[4][6] = 'h';
	mapa[4][7] = 'h';
	mapa[4][8] = 'n';
	mapa[4][9] = 'h';

	mapa[5][0] = 'h';
	mapa[5][1] = 'n';
	mapa[5][2] = 'c';
	mapa[5][3] = 'h';
	mapa[5][4] = 'n';
	mapa[5][5] = 'h';
	mapa[5][6] = '1';
	mapa[5][7] = 'd';
	mapa[5][8] = 'h';
	mapa[5][9] = 'h';

	mapa[6][0] = 'c';
	mapa[6][1] = '0';
	mapa[6][2] = 'c';
	mapa[6][3] = 'c';
	mapa[6][4] = 'p';
	mapa[6][5] = 'c';
	mapa[6][6] = 'c';
	mapa[6][7] = 'c';
	mapa[6][8] = 'c';
	mapa[6][9] = 'h';

	mapa[7][0] = 'c';
	mapa[7][1] = 'p';
	mapa[7][2] = 'h';
	mapa[7][3] = 'n';
	mapa[7][4] = 'h';
	mapa[7][5] = 'c';
	mapa[7][6] = 'h';
	mapa[7][7] = 'h';
	mapa[7][8] = 'c';
	mapa[7][9] = 'h';

	mapa[8][0] = 'h';
	mapa[8][1] = 'c';
	mapa[8][2] = 'c';
	mapa[8][3] = 'n';
	mapa[8][4] = 'c';
	mapa[8][5] = 'h';
	mapa[8][6] = 'c';
	mapa[8][7] = 'c';
	mapa[8][8] = 'c';
	mapa[8][9] = 'c';

	mapa[9][0] = 'n';
	mapa[9][1] = 'h';
	mapa[9][2] = 'c';
	mapa[9][3] = 'h';
	mapa[9][4] = 'c';
	mapa[9][5] = 'h';
	mapa[9][6] = 'h';
	mapa[9][7] = 'c';
	mapa[9][8] = 'c';
	mapa[9][9] = 'c';
*/
	//ignor = zachran_princezne(mapa, n, m, t,&d_cesty);

	//vypis_cesty(7, 5, 0, 0);


	int i, *cesta = zachran_princezne(mapa, n, m, t, &d_cesty);
//	for (i=0;i<d_cesty;++i){
	// printf("%d %d\n", cesta[i*2], cesta[i*2+1]);
//	}

//	printf("suradnice pred [ %d %d ] su [ %d %d ]\n",1,1,pole[1][1].sur_pred[0],pole[1][1].sur_pred[1]);
//	printf("suradnice pred [ %d %d ] su [ %d %d ]",5,2,pole[2][5].sur_pred[0],pole[2][5].sur_pred[1]);

/*	printf("suradnice pred [ %d %d ] su [ %d %d ]\n",1,0,pole[0][1].sur_pred[0],pole[0][1].sur_pred[1]);
	printf("suradnice pred [ %d %d ] su [ %d %d ]\n",1,1,pole[1][1].sur_pred[0],pole[1][1].sur_pred[1]);
	printf("suradnice pred [ %d %d ] su [ %d %d ]\n",2,1,pole[1][2].sur_pred[0],pole[1][2].sur_pred[1]);
	printf("suradnice pred [ %d %d ] su [ %d %d ]\n",3,1,pole[1][3].sur_pred[0],pole[1][3].sur_pred[1]);*/


//	printf("%d %d \n ",drak[0],drak[1]);

	return 0;
}
