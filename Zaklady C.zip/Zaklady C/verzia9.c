/*
/*
 * autor - Vladim�r Ve�erek
 * n�zov -verzia1.c
 * verzia -
 * d�tum -2017
 */

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

struct fanusik {
	char meno[100];
	int pocet_vpravo;
	int pocet_vlavo;
	int vyska;
	int status;
	struct fanusik *vpravo;
	struct fanusik *vlavo;
	struct fanusik *rodic;
};

struct stranka {
	char nazov_stranky[101];
	int pocet_users;
	struct stranka *dalsia;
	struct fanusik *koren;

};

typedef struct stranka stranka;
typedef struct fanusik fanusik;

struct stranka *Pole;
int Pozicia;

void init() {
	int n;
	n = 26*26*26*26;
	Pole = (stranka*) malloc(n * sizeof(stranka));

	/*
	 int debug =strlen(Pole[65151].nazov_stranky);
	 int debug2 =strlen(Pole[6555].nazov_stranky);
	 int debug3 =strlen(Pole[1245].nazov_stranky);

	 for(int i=0;i<n;i++){
	 Pole[i].dalsia = NULL;
	 Pole[i].nazov_stranky[0]= '\0';
	 Pole[i].pocet_users = 0;
	 }
	 */

}

// vytvorenie prislu�nej hodnoty pre stranku v hash tabulke
int hash_stranka(char *page) {

	long long int cislo = 0, i = 1,pom;
	char tmp = page[0];


	while (tmp != '\0') {

    pom=1;
    for(int j=0;j<i;j++){
	pom=(int)tmp * pom;
    }
   cislo +=pom;
		tmp = page[i];
		i++;

	}

	cislo = cislo % (26 * 26 * 26 * 26);
	return cislo;

}

//funkcia na n�jdenie smernika na stranku v Poli str�nok - vr�ti NULL ak sa tam str�nka nenach�dza ...
stranka* najdi_stranku(char *page, int poloha) {

	char pom[101];

//ak je tabulka prazdny na pozicii poloha alebo je tam spravna stranka

	if (strlen(Pole[poloha].nazov_stranky) == 0) {
		Pole[poloha].pocet_users = 0;
		strcpy(Pole[poloha].nazov_stranky, page);

		return &Pole[poloha];

	}

	if (strcmp(page, Pole[poloha].nazov_stranky) == 0) {
		return &Pole[poloha];
	}

//hladanie dalsej stranky

//zistenie �i  je to druha
	if (Pole[poloha].dalsia == NULL) {

		Pole[poloha].dalsia = (stranka*) malloc(sizeof(stranka));
		Pole[poloha].dalsia->pocet_users = 0;
		strcpy(Pole[poloha].dalsia->nazov_stranky, page);
		return Pole[poloha].dalsia;

	}
	strcpy(pom, Pole[poloha].dalsia->nazov_stranky);

	stranka *vrat = Pole[poloha].dalsia;
//cyklus a� k�m to nieje spravna alebo posledna
	while (strcmp(page, pom) != 0) {

		if (vrat->dalsia == NULL) {
			vrat->dalsia = (stranka*) malloc(sizeof(struct stranka));
			vrat->dalsia->pocet_users = 0;
			strcpy(vrat->dalsia->nazov_stranky, page);
			return vrat->dalsia;
		}

		vrat = vrat->dalsia;
		strcpy(pom, vrat->nazov_stranky);
	}

	return vrat;

}

//rot�cia LL
fanusik* rotacia1(fanusik *tmp) {

	fanusik *A, *C;

	A = tmp->vlavo;
	if (tmp->rodic != NULL) {
		if (tmp->rodic->vlavo == tmp) {
			tmp->rodic->vlavo = A;
		} else {
			tmp->rodic->vpravo = A;
		}
	}
	A->rodic = tmp->rodic;
	C = A->vpravo;
	A->vpravo = tmp;
	tmp->rodic = A;
	tmp->vlavo = C;
	if(C != NULL){
		C->rodic = tmp;
	}

	tmp->pocet_vlavo = A->pocet_vpravo;
	A->pocet_vpravo = tmp->pocet_vpravo + tmp->pocet_vlavo + 1;
	tmp->vyska = tmp->vyska - 2;

	return A->rodic;
}

//rot�cia LR
fanusik* rotacia2(fanusik *tmp) {

	fanusik *A, *B;

	A = tmp->vlavo;
	B = A->vpravo;

	if (tmp->rodic != NULL) {
		if (tmp->rodic->vlavo == tmp) {
			tmp->rodic->vlavo = B;
		} else {
			tmp->rodic->vpravo = B;
		}
	}
	B->rodic = tmp->rodic;
	A->vpravo = B->vlavo;

	if(B->vlavo != NULL){
		B->vlavo->rodic = A;
	}

	A->rodic = B;
	tmp->rodic = B;
	tmp->vlavo = B->vpravo;

	if(B->vpravo != NULL){
			B->vpravo->rodic = tmp;
			}

	B->vlavo = A;
	B->vpravo = tmp;

	A->pocet_vpravo = B->pocet_vlavo ;
	tmp->pocet_vlavo = B->pocet_vpravo ;
	B->pocet_vlavo = A->pocet_vpravo + A->pocet_vlavo + 1;
	B->pocet_vpravo = tmp->pocet_vpravo + tmp->pocet_vlavo + 1;

	B->vyska++;
	tmp->vyska = tmp->vyska - 2;
	A->vyska--;

	return B->rodic;

}

//rot�cia RR
fanusik* rotacia3(fanusik *tmp) {

	fanusik *A;

	A = tmp->vpravo;

	if (tmp->rodic != NULL) {

		if (tmp->rodic->vlavo == tmp) {
			tmp->rodic->vlavo = A;
		} else {
			tmp->rodic->vpravo = A;
		}
	}

	A->rodic = tmp->rodic;
	tmp->vpravo = A->vlavo;
	if (A->vlavo != NULL) {
		A->vlavo->rodic = tmp;

	}
	tmp->pocet_vpravo =A->pocet_vlavo ;

	if (A->vlavo != NULL) {
		A->vlavo->rodic = tmp;
	}
	tmp->rodic = A;
	A->vlavo = tmp;
	tmp->vyska = tmp->vyska - 2;


	A->pocet_vlavo= A->vlavo->pocet_vlavo +A->vlavo->pocet_vlavo+1;



	return A->rodic;

}

//rot�cia RL
fanusik* rotacia4(fanusik *tmp) {

	fanusik *A, *B;

	A = tmp->vpravo;
	B = A->vlavo;

	if (tmp->rodic != NULL) {
		if (tmp->rodic->vlavo == tmp) {
			tmp->rodic->vlavo = B;
		} else {
			tmp->rodic->vpravo = B;
		}
	}
	tmp->vpravo = B->vlavo;

	if(B->vlavo != NULL){
	B->vlavo->rodic = tmp;

	}


	B->rodic = tmp->rodic;
	tmp->rodic = B;
	A->vlavo = B->vpravo;

	if(B->vpravo != NULL){
		B->vpravo->rodic = A;
		}

	A->rodic = B;
	B->vlavo = tmp;
	B->vpravo = A;

	B->vyska++;
	A->vyska--;
	tmp->vyska = tmp->vyska - 2;

	tmp->pocet_vpravo = B->pocet_vlavo;
	A->pocet_vlavo = B->pocet_vpravo;
	B->pocet_vpravo = A->pocet_vlavo + A->pocet_vpravo +1;
	B->pocet_vlavo = tmp->pocet_vlavo + tmp->pocet_vpravo +1;


	return B->rodic;

}

// pidanie fan��ika do stomu danej str�nky
void like(char *page, char *user) {


	stranka *tmp = NULL;
	fanusik *miesto, *pred = NULL;

//zistenie pozicie v Hash tabulke
	int poloha;
	poloha = hash_stranka(page);

	tmp = najdi_stranku(page, poloha);


//ak je koren stromu pr�zdny vytvor� sa nov� strom
	if (tmp->pocet_users == 0) {
		tmp->pocet_users = 1;
		tmp->dalsia = NULL;
		strcpy(tmp->nazov_stranky, page);
		tmp->koren = (fanusik*) malloc(sizeof(fanusik));
		tmp->koren->pocet_vlavo = 0;
		tmp->koren->pocet_vpravo = 0;
		tmp->koren->vyska = 1;
		tmp->koren->vlavo = NULL;
		tmp->koren->vpravo = NULL;
		tmp->koren->rodic = NULL;
		tmp->koren->status =1;
		strcpy(tmp->koren->meno, user);

	} else {
//ak je u� koren stromu vytvoren�

		tmp->pocet_users++;
		fanusik *novy;
		novy = (fanusik*) malloc(sizeof(fanusik));
		novy->vlavo = NULL;
		novy->vpravo = NULL;
		novy->vyska = 1;
		novy->status=1;
		novy->pocet_vlavo = 0;
		novy->pocet_vpravo = 0;
		strcpy(novy->meno, user);
// pokra�uj v strome

//najdenie poz�cie na ulo�enie
		miesto = tmp->koren;

		while (miesto != NULL) {
			miesto->vyska++;
			if (strcmp(novy->meno, miesto->meno) == 0){
				miesto->status =1;
				return;
			}


			if (strcmp(novy->meno, miesto->meno) < 0) {
				pred = miesto;
				miesto->pocet_vlavo++;
				miesto = miesto->vlavo;

			} else {
				pred = miesto;
				miesto->pocet_vpravo++;
				miesto = miesto->vpravo;
			}

		}

		novy->rodic = pred;
		miesto = novy;

		if (strcmp(miesto->meno, pred->meno) < 0) {

			pred->vlavo = miesto;

		} else {
			pred->vpravo = miesto;

		}

// vyva�ovanie - hladanie nevyv�en�ho uzla

		if (pred->rodic == NULL) {
			return;
		}

		int rozdiel, rotacia = 0;
		pred = pred->rodic;


		if (pred->rodic == NULL) {
			fanusik *A, *B,*C;
			C=novy->rodic;

			if (pred->vlavo == NULL) {
				A = pred->vpravo;
				if (A->vpravo == NULL) {
					B = A->vlavo;

					B->rodic = NULL;
					B->vlavo = pred;
					B->vpravo = A;
					pred->pocet_vpravo = 0;
					A->pocet_vlavo--;
					pred->rodic = B;
					A->rodic = B;
					B->pocet_vpravo++;
					B->pocet_vlavo++;

					tmp->koren = B;
					pred->vyska = pred->vyska - 2;
					B->vyska++;
					A->vyska--;
					pred->vpravo = NULL;
					A->vlavo = NULL;

				} else {

					A->rodic = NULL;
					tmp->koren = A;

					A->vlavo = pred;
					pred->rodic = A;
					pred->pocet_vpravo = 0;
					A->pocet_vlavo++;
					A->vyska = 2;
					pred->vyska = 1;
					pred->vpravo = NULL;

				}

			} else {
				if (pred->vpravo == NULL) {

					A = pred->vlavo;
					if (A->vpravo == NULL) {

						A->rodic = NULL;
						tmp->koren = A;

						A->vpravo = pred;
						pred->rodic = A;
						pred->pocet_vlavo = 0;
						A->pocet_vpravo++;
						A->vyska = 2;
						pred->vyska = 1;
						pred->vlavo = NULL;

					} else {

						B = A->vpravo;

						B->rodic = NULL;
						B->vpravo = pred;
						B->vlavo = A;
						pred->pocet_vlavo = 0;
						A->pocet_vpravo--;
						pred->rodic = B;
						A->rodic = B;
						B->pocet_vpravo++;
						B->pocet_vlavo++;
						tmp->koren = B;
						pred->vyska = pred->vyska - 2;
						B->vyska++;
						A->vyska--;
						pred->vlavo = NULL;
						A->vpravo = NULL;

					}
				}else{

					while(C!=NULL){
						if (C->vlavo == NULL) {
							C->vyska = C->vpravo->vyska + 1;
						} else {
							if (C->vpravo == NULL) {
								C->vyska = C->vlavo->vyska + 1;
							} else {
								if ((C->vpravo->vyska - C->vlavo->vyska)
										< 0) {
									C->vyska = C->vlavo->vyska + 1;
								} else {
									C->vyska = C->vpravo->vyska + 1;
								}
							}

						}
						C=C->rodic;

					}

				}
			}


			return;

		}

		while (pred != NULL) {

//zistenie typu rot�cie 1=LL,2=LR,3=RR,4=RL
			if (pred->vlavo == NULL || pred->vpravo == NULL) {
				rotacia = 2;

				if (strcmp(novy->meno, pred->meno) <= 0) {

					if (strcmp(novy->meno, pred->vlavo->meno) <= 0) {
						rotacia = 1;
						pred = rotacia1(pred);

					} else {
						rotacia = 2;
						pred = rotacia2(pred);
					}

				} else {
					if (strcmp(novy->meno, pred->vpravo->meno) <= 0) {
						rotacia = 4;
						pred = rotacia4(pred);

					} else {
						rotacia = 3;
						pred = rotacia3(pred);

					}

				}

				if (pred == NULL) {
					tmp->koren = tmp->koren->rodic;
				}

			} else {

				if (pred->vlavo->vyska > pred->vpravo->vyska) {
					rozdiel = pred->vlavo->vyska - pred->vpravo->vyska;

					if (rozdiel >= 2) {
						if (strcmp(novy->meno, pred->vlavo->meno) <= 0) {
							rotacia = 1;
							pred = rotacia1(pred);

						} else {
							rotacia = 2;
							pred = rotacia2(pred);
						}

						if (pred == NULL) {
							tmp->koren = tmp->koren->rodic;
						}
					}

				} else {
					rozdiel = pred->vpravo->vyska - pred->vlavo->vyska;
					if (rozdiel >= 2) {
						if (strcmp(novy->meno, pred->vpravo->meno) <= 0) {
							rotacia = 4;
							pred = rotacia4(pred);
						} else {
							rotacia = 3;
							pred = rotacia3(pred);
						}
						if (pred == NULL) {
							tmp->koren = tmp->koren->rodic;
						}
					}

				}

			}

			if (pred == NULL) {
				break;
			}

			if (pred->vlavo == NULL) {
				pred->vyska = pred->vpravo->vyska + 1;
			} else {
				if (pred->vpravo == NULL) {
					pred->vyska = pred->vlavo->vyska + 1;
				} else {
					if ((pred->vpravo->vyska - pred->vlavo->vyska) < 0) {
						pred->vyska = pred->vlavo->vyska + 1;
					} else {
						pred->vyska = pred->vpravo->vyska + 1;
					}
				}

			}
			if (rotacia == 0) {
				pred = pred->rodic;
			}

			rotacia = 0;
		}

	}

}

void unlike(char *page, char *user) {


	stranka *tmp = NULL;
	fanusik *miesto, *pred = NULL ,*A,*B;

//zistenie pozicie v Hash tabulke
	int poloha;
	poloha = hash_stranka(page);
	tmp = najdi_stranku(page, poloha);


	miesto = tmp->koren;
	tmp->pocet_users--;

//zmazanie z prveho miesta
	if(strcmp(user, tmp->koren->meno)==0){
		if(tmp->koren->vyska == 1){
			pred = tmp->koren;
			free(pred);
			tmp->koren = NULL;
			return;
		}
//mo�nos� prava strana prazdna
		if(tmp->koren->vpravo == NULL ){
			A=tmp->koren->vlavo;
			pred = tmp->koren;
			free(pred);
			tmp->koren = A;
			A->rodic = NULL;
			A->vyska =1;
			return;
		}
//lava strana prazdna
		if(tmp->koren->vlavo == NULL ){
			A=tmp->koren->vpravo;
			pred = tmp->koren;
			free(pred);
			tmp->koren = A;
			A->rodic = NULL;
			A->vyska =1;
			return;
		}
//jednoduch� strom o dvoch vetv�ch v��ky 1
		if(tmp->koren->pocet_vlavo== 1 && tmp->koren->pocet_vpravo == 1){
			A=tmp->koren->vlavo;
			B=tmp->koren->vpravo;

			pred = tmp->koren;
			free(pred);

			tmp->koren = A;
			A->rodic = NULL;
			A->vyska = 2;
			A->pocet_vpravo = 1;
			A->vpravo = B;
			B->rodic =A;

			return;

		}

//strom  s neur�itou v��kov vpravo a vlavo
		if(tmp->koren->pocet_vlavo >= 1 && tmp->koren->pocet_vpravo >= 1){

			A=tmp->koren->vlavo;
			B=tmp->koren->vpravo;

			if(B->vlavo == NULL && A->vpravo != NULL && tmp->koren->vyska <= 4){

				pred = tmp->koren;
				free(pred);

				tmp->koren =B;
				B->vlavo = A;
				B->rodic = NULL;
				A->rodic = B;
				B->vyska =A->vyska+1;
				B->pocet_vlavo = A->pocet_vlavo + A->pocet_vpravo + 1;

				return;

			}
			if (A->vpravo == NULL && B->vlavo != NULL && tmp->koren->vyska <= 4) {

				pred = tmp->koren;
				free(pred);

				tmp->koren = A;
				A->vpravo = B;
				A->rodic = NULL;
				B->rodic = A;
				A->vyska = B->vyska + 1;
				A->pocet_vpravo = B->pocet_vlavo + B->pocet_vpravo + 1;
				return;

			}

			if(A->vpravo == NULL && B->vlavo == NULL){

				if(tmp->koren->pocet_vpravo >= tmp->koren->pocet_vlavo){

					pred = tmp->koren;
					free(pred);

					tmp->koren = B;
					B->vlavo = A;
					A->rodic =B;
					B->vyska = A->vyska+1;
					B->pocet_vlavo = A->pocet_vlavo +1;
					B->rodic = NULL;

				}else{

					pred = tmp->koren;
					free(pred);

					tmp->koren = A;
					A->vpravo = B;
					B->rodic = A;
					A->vyska = B->vyska + 1;
					A->pocet_vpravo = B->pocet_vpravo + 1;
					A->rodic = NULL;


				}

				return ;

			}



			tmp->koren->status =0;
			return ;
		}





	}

	pred = NULL;


	while (strcmp(user, miesto->meno) != 0) {

		if (strcmp(user, miesto->meno) < 0) {
			pred = miesto;
			miesto->pocet_vlavo--;
			miesto = miesto->vlavo;

		} else {
			pred = miesto;
			miesto->pocet_vpravo--;
			miesto = miesto->vpravo;
		}

	}

	miesto->status =0;


return;

}

char *getuser(char *page, int k) {


	stranka *tmp = NULL;
	fanusik *miesto, *pred = NULL, *A, *B;

//zistenie pozicie v Hash tabulke
	int poloha;
	poloha = hash_stranka(page);
	tmp = najdi_stranku(page, poloha);

	if (tmp->pocet_users < k) {
		return NULL;
	}

//rozhodnutie , hlada� vlavo alebo vpravo :D

	if (tmp->koren->pocet_vlavo >= k) {
		A = tmp->koren;
		while (A->pocet_vlavo > k) {
			A = A->vlavo;
		}
		if ((k - A->pocet_vlavo) == 0) {

			if(A->vlavo == NULL){
				return A->meno;
			}

			while (A->vlavo->status == 0) {
				A = A->vlavo;
			}

			A = A->vlavo;


			while (A->vpravo != NULL) {
			A = A->vpravo;
			}

			return A->meno;
		}

		B = A->vpravo;
		if ((k - A->pocet_vlavo) == 1) {
			return A->meno;
		}

		if ((k - A->pocet_vlavo - 1) == 1) {
			while (B->pocet_vlavo != 0) {
				B = B->vlavo;
			}
			return B->meno;
		}

		k = k - A->pocet_vlavo;

		while (k != 0) {
			B = A->vpravo;

			while (k > B->pocet_vlavo) {

				if (B->status == 0) {
					k = k - B->pocet_vlavo;
				} else {
					k = k - B->pocet_vlavo - 1;
				}
				if (k == 0) {
					return B->meno;
				}

				B = B->vpravo;
			}



			while (k > A->pocet_vlavo) {
				A = A->vlavo;
			}

		}
		return A->meno;

	}else{
		A = tmp->koren;
		k=k-A->pocet_vlavo;


		if(k==1){

			return A->meno;
		}


		while (k != 0) {
			B = A->vpravo;


			while (k > B->pocet_vlavo) {

				if (B->status == 0) {
					k = k - B->pocet_vlavo;
				} else {
					k = k - B->pocet_vlavo - 1;
				}


				if(k == 0){
					A=B->vlavo;
					if(B->pocet_vlavo == 0){
						return B->meno;
					}

					while(A->pocet_vpravo != 0){
						A=A->vpravo;
					}
					return A->meno;

				}

				if(k==1){
					return B->meno;
				}

				B = B->vpravo;
			}

			A=B->vlavo;
			if (k == B->pocet_vlavo) {
				while (A->pocet_vlavo != 0) {
					A = A->vlavo;
				}
				return A->meno;

			}


			while (k > A->pocet_vlavo) {
				A = A->vlavo;
			}




		}
		return A->meno;



	}


	return page;
}

// Vlastna funkcia main() je pre vase osobne testovanie. Dolezite: pri testovacich scenaroch sa nebude spustat!
int main() {
	init();
	like("ab", "m");
	like("ab", "b");
	like("ab", "c");
	like("ab", "n");
	like("ab", "e");
	like("ab", "f");
	like("ab", "d");
	like("ab", "h");
	like("ab", "i");
	like("ab", "a");



	like("ab", "ab");
/*
	like("ab", "ac");
	like("ab", "bc");
	like("ab", "cd");
	like("ab", "ad");
	like("ab", "bf");
	like("ab", "sd");
*/


	unlike("ab","b");
	unlike("ab","h");

	like("ab", "x");
	like("ab", "y");
	unlike("ab","y");
	unlike("ab","a");


	unlike("ab","n");


	char *page = "ab";
	char *najdi;
	int k=11;

	int debag;
	debag = hash_stranka(page);
	najdi = getuser(page, k);

	printf("%s",najdi);


//	printf("%d \n", debag);




	printf("%s %d %d %d\n", Pole[debag].koren->meno, Pole[debag].koren->vyska,Pole[debag].koren->pocet_vlavo,Pole[debag].koren->pocet_vpravo);
	printf("%s %d\n", Pole[debag].koren->vlavo->meno,
			Pole[debag].koren->vlavo->vyska);
	printf("%s %d\n", Pole[debag].koren->vpravo->meno,
			Pole[debag].koren->vpravo->vyska);
	printf("%s %d    %d %d\n", Pole[debag].koren->vpravo->vpravo->meno,
			Pole[debag].koren->vpravo->vpravo->vyska ,Pole[debag].koren->vpravo->vpravo->pocet_vlavo,Pole[debag].koren->vpravo->vpravo->pocet_vpravo );
	printf("%s %d\n", Pole[debag].koren->vpravo->vlavo->meno,
			Pole[debag].koren->vpravo->vlavo->vyska);
	printf("%s %d\n", Pole[debag].koren->vlavo->vlavo->meno,
				Pole[debag].koren->vlavo->vlavo->vyska);
	printf("%s %d\n", Pole[debag].koren->vlavo->vpravo->meno,
				Pole[debag].koren->vlavo->vpravo->vyska);

	printf("%s %d\n", Pole[debag].koren->vlavo->vlavo->vlavo->meno,
					Pole[debag].koren->vlavo->vlavo->vlavo->vyska);
	printf("%s %d\n", Pole[debag].koren->vpravo->vlavo->vlavo->meno,
					Pole[debag].koren->vpravo->vlavo->vlavo->vyska);
	printf("%s %d\n", Pole[debag].koren->vpravo->vlavo->vpravo->meno,
					Pole[debag].koren->vpravo->vlavo->vpravo->vyska);
	printf("%s %d\n", Pole[debag].koren->vpravo->vpravo->vpravo->meno,
					Pole[debag].koren->vpravo->vpravo->vpravo->vyska);
	printf("%s %d   %d %d\n", Pole[debag].koren->vpravo->vpravo->vlavo->meno,
					Pole[debag].koren->vpravo->vpravo->vlavo->vyska,Pole[debag].koren->vpravo->vpravo->vlavo->pocet_vlavo ,Pole[debag].koren->vpravo->vpravo->vlavo->pocet_vpravo);




	/*
	 like("Star Wars", "Marek");
	 like("Star Trek", "Filip");
	 printf("%s\n", getuser("Star Trek", 1)); // Filip
	 printf("%s\n", getuser("Star Trek", 2)); // Jana
	 unlike("Star Trek", "Filip");
	 printf("%s\n", getuser("Star Trek", 1)); // Jana
	 */
	return 0;
}
