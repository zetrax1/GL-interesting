/*
 * autor - Vladim�r Ve�erek
 * n�zov -4_1.c
 * verzia -
 * d�tum -2017
 */

#include <stdio.h>
#include <stdlib.h>

struct blok {

	char *meno;
	int hodnota;

};
typedef struct blok blok;

struct blok pole[100000];

void vloz(char *meno, int hodnota)
{


	if (pole[0].hodnota == 0) {
		pole[0].hodnota = hodnota;
		pole[0].meno = meno;
		return;
	} else {

		int i = 0;
		while (pole[i].hodnota != 0) {
			i++;
		}

		pole[i].hodnota = hodnota;
		pole[i].meno = meno;

		char *pom_meno;
		int pom_hodnota;
		int akt;

		while ((i - 1) / 2 != 0) {

			akt = (i - 1) / 2;

			if (pole[akt].hodnota >= pole[i].hodnota) {
				return;

			} else {
				pom_hodnota = pole[akt].hodnota;
				pom_meno = pole[akt].meno;
				pole[akt].hodnota = pole[i].hodnota;
				pole[akt].meno = pole[i].meno;
				pole[i].meno = pom_meno;
				pole[i].hodnota = pom_hodnota;
			}
			i = akt;
		}
		if (i == 2 || i == 1) {
			if (pole[0].hodnota >= pole[i].hodnota) {
				return;

			} else {
				pom_hodnota = pole[0].hodnota;
				pom_meno = pole[0].meno;
				pole[0].hodnota = pole[i].hodnota;
				pole[0].meno = pole[i].meno;
				pole[i].meno = pom_meno;
				pole[i].hodnota = pom_hodnota;
			}

		}

	}

	return;
}

char *vyber_najvyssie() {

	char *pom_meno = pole[0].meno;
	int i = 0;

	while (((pole[2 * i + 2].hodnota != 0) + (pole[2 * i + 1].hodnota != 0))
			!= 0) {

		if (pole[2 * i + 1].hodnota >= pole[2 * i + 2].hodnota) {
			pole[i].meno = pole[2 * i + 1].meno;
			pole[i].hodnota = pole[2 * i + 1].hodnota;
			i = 2 * i + 1;
		} else {
			pole[i].meno = pole[2 * i + 2].meno;
			pole[i].hodnota = pole[2 * i + 2].hodnota;
			i = 2 * i + 2;
		}

	}
	pole[i].hodnota = 0;

	return pom_meno;

}

int main() {

	char buf[100];
	int x=7;


	for (int i = 0; i < 100000; i++) {
		pole[i].hodnota = 0;
		pole[i].meno="\0";
	}




	  while (scanf("%s", buf) > 0)
	 {
	 if (!strcmp(buf, "vyber"))
	 printf("%s\n", vyber_najvyssie());
	 else
	 {
	 scanf("%s %d", buf, &x);
	 vloz(buf, x);
	 for(int a = 0;a<5;a++){
		 printf("%s",pole[a].meno);
	 }
	 }
	 }

	return 0;
}
