#pragma once
class Hrac
{
private:
	struct karta{
		char znak;
		int hodnota;
		struct karta *dalsi;
	};

	karta *front; //zaciatok zoznamu
	karta *rear; //koniec zoznamu
	int num;	//pocet poloziek ,aktu�lny
	int max;   // maximalne mnozstvo poloziek ,max pocet kariet 




public:


	void add(char z, int value);
	bool zmaz();
	int get_num();
	void presun();
	void vypis_kariet();
	int get_value();
	char get_znak();
	void set_num(int nove);

	Hrac(int size);
	~Hrac();
};

