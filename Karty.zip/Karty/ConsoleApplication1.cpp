// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include "Hrac.h"
#include <time.h>


void add_rand_kartu(int cislo,Hrac *hn)
{
	int tmp_num = 0;
	char tmp_zn;


	if (cislo < 8) {
		tmp_num = cislo + 1;
		tmp_zn = 'A';
	}
	if (cislo > 7 && cislo < 16) {
		tmp_num = cislo - 7;
		tmp_zn = 'B';
	}
	if (cislo > 15 && cislo < 24) {
		tmp_num = cislo - 15;
		tmp_zn = 'C';
	}
	if (cislo > 23 && cislo < 32) {
		tmp_num = cislo - 23;
		tmp_zn = 'D';
	}

	hn->add(tmp_zn, tmp_num);
//	printf("%d  %c \n", tmp_num, tmp_zn);


}



int random_cislo(int i) {
	srand(i);

	return (rand() % 32);
}


bool over(int tmp,int *pole,int i) {

	for (int j = 0; j < i; j++) {
		if (tmp == pole[j]) {
			return true;
		}
	}
	return false;
}

void zamiesaj(int **pole) {

	int tmp;
	int l=0;
	for (int i = 0; i < 32; i++) {
		tmp = random_cislo(l);
	//	printf("%d \n", tmp);
		if (over(tmp, *pole, i)) {
			i--;
		//	printf("zhoda\n");
		}
		else {
			(*pole)[i] = tmp;
			printf("%d \n", tmp);
		}
	

		l++;
	}
}

void rozdaj(Hrac *hn,int od,int *pole) {
	for (int i = 0; i < 8; i++) {
		add_rand_kartu(pole[od+i],hn);
	}

}




int vytaz(Hrac *h1, Hrac *h2, Hrac *h3, Hrac *h4) {
	
	int vin = 1;
	
	int max = h1->get_value();

	char akt = h1->get_znak();

	if (h2->get_value() >= max ) {
		if (h2->get_value() == max) {
			if (h2->get_znak() < akt) {
				vin = 2;
				max = h2->get_value();
				akt = h2->get_znak();
			}
		}
		else {
			vin = 2;
			max = h2->get_value();
			akt = h2->get_znak();
		}
		
	}
	if (h3->get_value() >= max) {
		if (h3->get_value() == max) {
			if (h3->get_znak() < akt) {
				vin = 3;
				max = h3->get_value();
				akt = h3->get_znak();
			}
		}
		else {
			vin = 3;
			max = h3->get_value();
			akt = h3->get_znak();
		}

	}
	if (h4->get_value() >= max) {
		if (h4->get_value() == max) {
			if (h4->get_znak() < akt) {
				vin = 4;
				max = h4->get_value();
				akt = h4->get_znak();
			}
		}
		else {
			vin = 4;
			max = h4->get_value();
			akt = h4->get_znak();
		}

	}

	printf("karty na stole : \nh1: %d %c \nh2: %d %c \nh3: %d %c \nh4: %d %c\n", h1->get_value(), h1->get_znak(), h2->get_value(), h2->get_znak(), h3->get_value(), h3->get_znak(), h4->get_value(), h4->get_znak());
	printf("Vyhral hrac cislo: %d\n\n", vin);

	return vin;
}

void hod(Hrac *h1, Hrac *h2, Hrac *h3, Hrac *h4) {

	int vin=3;
	vin = vytaz(h1, h2, h3, h4);
	if (vin == 1) {
		h1->presun();
		h1->add(h2->get_znak(), h2->get_value());
		h1->add(h3->get_znak(), h3->get_value());
		h1->add(h4->get_znak(), h4->get_value());

		h2->zmaz();
		h3->zmaz();
		h4->zmaz();
			return;
	}
	if (vin == 2) {
		h2->presun();
		h2->add(h1->get_znak(), h1->get_value());
		h2->add(h3->get_znak(), h3->get_value());
		h2->add(h4->get_znak(), h4->get_value());

		h1->zmaz();
		h3->zmaz();
		h4->zmaz();
		return;
	}
	if (vin == 3) {
		h3->presun();
		h3->add(h2->get_znak(), h2->get_value());
		h3->add(h1->get_znak(), h1->get_value());
		h3->add(h4->get_znak(), h4->get_value());

		h2->zmaz();
		h1->zmaz();
		h4->zmaz();
		return;
	}
	if (vin == 4) {
		h4->presun();
		h4->add(h2->get_znak(), h2->get_value());
		h4->add(h3->get_znak(), h3->get_value());
		h4->add(h1->get_znak(), h1->get_value());

		h2->zmaz();
		h3->zmaz();
		h1->zmaz();
		return;
	}
	

}


int min(int a, int b) {
	if (a > b) {
		return b;
	}
	else {
		return a;
	}
}


int max(int a, int b) {
	if (a > b) {
		return a;
	}
	else {
		return b;
	}
}

void vysledok_hry(Hrac *h1, Hrac *h2, Hrac *h3, Hrac *h4)
{
	int tmp=h1->get_num();
	int x=1, y;
	if (h2->get_num() >= tmp) {
		if (h2->get_num() == tmp) {
			y = 1;
		}
	}

	
}

int kolo(Hrac *h1, Hrac *h2, Hrac *h3, Hrac *h4) 
{
	int poc_hod = 0;
	int x, y;
	x = min(h1->get_num(), h2->get_num());
	y = min(h3->get_num(), h4->get_num());
	poc_hod = min(x, y);
	printf("\n%d  %d  %d  %d----\n", h1->get_num(), h2->get_num(), h3->get_num(), h4->get_num());

	printf("\n%d ----\n", poc_hod);
	if (poc_hod == 0) {
		return 1;
	}
	for (int i = 0; i < poc_hod; i++) {
		hod(h1, h2, h3, h4);
	}
	return 0;
}

int main()
{
	int *pole = (int*)malloc(32 * sizeof(int));
	zamiesaj(&pole);
	
	//vytvorenie hracov :D
	Hrac *h1 = new Hrac(32);
	Hrac *h2 = new Hrac(32);
	Hrac *h3 = new Hrac(32);
	Hrac *h4 = new Hrac(32);

	rozdaj(h1,0,pole);
	rozdaj(h2, 8, pole);
	rozdaj(h3, 16, pole);
	rozdaj(h4, 24, pole);


	int koniec = 0;
	while (koniec == 0) {
		koniec = kolo(h1, h2, h3, h4);
	}
	
	
	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
