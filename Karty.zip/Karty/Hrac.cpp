#include "pch.h"
#include "Hrac.h"
#include<stdio.h>


Hrac::Hrac(int size):front(nullptr) , rear(nullptr), num(0), max(size)
{
}


void Hrac::add(char z, int value) 
{
	karta *pridaj = new karta();
	pridaj->hodnota = value;
	pridaj->znak = z;
	pridaj->dalsi = nullptr;
	
	if (num == 0) {
		this->front = pridaj;
		this->rear = pridaj;
		this->num++;
		return;
	}


	
	rear->dalsi = pridaj;
	rear = rear->dalsi;
	this->num++;


}


bool Hrac::zmaz()
{
	if (this->num == 0) {
		return false;
	}
	karta *tmp = front;
	front = front->dalsi;
	delete(tmp);
	this->num--;
	return true;
}

int Hrac::get_num()
{
	return this->num;
}


void Hrac::presun()
{
	//presun prvej karty na posledne miesto ;
	karta *tmp;
	tmp = front;
	rear->dalsi = tmp;
	rear = rear->dalsi;
	front = front->dalsi;
	tmp->dalsi = nullptr;

	
}

int Hrac::get_value()
{

	return front->hodnota;

}


void Hrac::vypis_kariet() 
{
	printf("%d\n",num);
	karta *tmp = front;
	for (int i = 0; i < num; i++) {
		
		printf("%d   %c\n", tmp->hodnota, tmp->znak);
		tmp = tmp->dalsi;

	}
	if (tmp == nullptr) {
		printf("koniec");
	}
	printf("\n");

}




char Hrac::get_znak() {
	return front->znak;
}


void Hrac::set_num(int nove) {
	this->num = nove;
}

Hrac::~Hrac()
{
	while (num != 0) {
		zmaz();
	}

}
