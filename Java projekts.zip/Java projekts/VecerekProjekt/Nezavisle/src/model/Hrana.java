package model;

public class Hrana {
	
	
	private boolean orientacia ;
	private int hodnota = 0;
	private String vstupny;
	private String vystupny;

	public Hrana(String vs , String vy , boolean orien) {
		
		this.vstupny = vs;
		this.vystupny = vy;
		this.orientacia = orien;
	}

    public Hrana(String vs , String vy , boolean orien,int hod) {
		
		this.vstupny = vs;
		this.vystupny = vy;
		this.orientacia = orien;
		this.hodnota = hod;
		
	}

	public boolean isOrientacia() {
		return orientacia;
	}

	public void setOrientacia(boolean orientacia) {
		this.orientacia = orientacia;
	}

	public int getHodnota() {
		return hodnota;
	}

	public void setHodnota(int hodnota) {
		this.hodnota = hodnota;
	}

	public String getVstupny() {
		return vstupny;
	}

	public void setVstupny(String vstupny) {
		this.vstupny = vstupny;
	}

	public String getVystupny() {
		return vystupny;
	}

	public void setVystupny(String vystupny) {
		this.vystupny = vystupny;
	}
	
    
	
	
	
}
