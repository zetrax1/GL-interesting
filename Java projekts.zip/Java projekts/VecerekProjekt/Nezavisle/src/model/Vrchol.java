package model;

import java.util.ArrayList;

public class Vrchol {
	
	
	private String nazov;
	private int stupen;
	private int navstiveny;
	private boolean koncovy;
	private ArrayList<Hrana> hranaList ;
	

	public Vrchol(String nazov) {
		this.nazov = nazov;
		this.navstiveny =0;
		hranaList  = new ArrayList<Hrana>();
	}



	public String getNazov() {
		return nazov;
	}



	public void setNazov(String nazov) {
		this.nazov = nazov;
	}



	public int getStupen() {
		return stupen;
	}



	public void setStupen(int stupen) {
		this.stupen = stupen;
	}



	public int getNavstiveny() {
		return navstiveny;
	}



	public void setNavstiveny(int navstiveny) {
		this.navstiveny = navstiveny;
	}



	public boolean isKoncovy() {
		return koncovy;
	}



	public void setKoncovy(boolean koncovy) {
		this.koncovy = koncovy;
	}
	
	

}
