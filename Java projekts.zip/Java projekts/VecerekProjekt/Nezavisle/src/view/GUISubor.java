package view;




import controller.Controller;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;




public class GUISubor extends Stage  {

	private Text popisText = new Text ("Vlozte cestu k súboru s Grafom ");
	private TextField cestaSubor = new TextField();
	private Button pridajBut = new Button("pridaj");
	private Text HistText = new Text ("Historia Suborov");
	private Text textSub = new Text();
	private ScrollPane scroll = new ScrollPane();
	

	public GUISubor(Controller controller) {
		
		
		setTitle("Suborove menu");
		GridPane subOkno = new GridPane();
		subOkno.setHgap(5);
		subOkno.setVgap(5);
		subOkno.setPadding(new Insets(20,40,20,40));
		
		
		
		  subOkno.getChildren().addAll(popisText,cestaSubor,pridajBut,HistText,scroll);
		  
		  GridPane.setConstraints(popisText,1,1);
		  GridPane.setConstraints(cestaSubor,1,2);
		  GridPane.setConstraints(pridajBut,2,2);
		  GridPane.setConstraints(HistText,1,4);
		  
		  
		 
		 GridPane.setConstraints(scroll,1,5); scroll.setPrefSize(100, 200);
		  
		 textSub.setText(controller.historyFileR());
		 scroll.setContent(textSub);
		 
		
		  pridajBut.setOnAction(e -> {
		  
		  
		  try{ 
		  controller.grafSubor(cestaSubor.getText());
		  System.out.print(cestaSubor.getText());
		  
		  } catch (Exception e1){
		  
		  Alert Chyba = new Alert(AlertType.ERROR);
		  Chyba.setTitle("Chyba");
		  Chyba.setContentText("Neplatne Udaje");
		  Chyba.showAndWait();
		  
		  }
		  
		 
		 
		 });
		 
		
		
		Scene scene = new Scene(subOkno,400,400);
		setScene(scene);
		show();
		
		
		
		
	}
	
	
}
