package view;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import controller.Controller;
import javafx.geometry.Insets;



public class GUIHlavnaScena extends Stage {

	//tlacidla
	private Button grafSubor = new Button("Nacitaj Graf");
	private Button grafTvorba = new Button("Vytvor Graf");
	//----------------------------------------------------
	private Button algExistencia = new Button("Existencia");
	private Button algRovina = new Button("Rovinny");
	private Button algMatica = new Button("Matica susednosti");
	private Button algSuvisly = new Button("Suvislosť / Tarryho");
	private Button algFloydov = new Button("Floydov");
	private Button algDikstra = new Button("Dikstra");	
	//----------------------------------------------------
	private Button infExis = new Button("Inf");
	private Button infRov = new Button("Inf");
	private Button infMat = new Button("Inf");
	private Button infSuv = new Button("Inf");
	private Button infFloyd = new Button("Inf");
	private Button infDiks = new Button("Inf");
	//texty
	private Text menu = new Text ("Algoritmy na prácu s grafom");
	private Controller controller;
	
	// základne nastavenia rozmerov pre tlacidlo
	private void nastavenieB( Button tlacidlo) {

		tlacidlo.setStyle(     
                "-fx-min-width: 250px; " +
                "-fx-min-height: 30px; " +
                "-fx-max-width: 300px; " +
                "-fx-max-height: 30px;"
        );
		
	}
	
	private void nastavenieInf( Button tlacidlo) {

		tlacidlo.setStyle(     
                "-fx-min-width: 50px; " +
                "-fx-min-height: 30px; " +
                "-fx-max-width: 50px; " +
                "-fx-max-height: 30px;"
        );
		
	}
	
	
	public GUIHlavnaScena() {
		
		super();
		controller = new Controller();
		
		//zakladne nastavenia pre Hlavne menu , rozmery , nadpis 
		setTitle("Hlavne menu");
		GridPane hlOkno = new GridPane();
		hlOkno.setHgap(10);
		hlOkno.setVgap(5);
		hlOkno.setPadding(new Insets(20,50,20,50));
		
		
		// pridanie tlacidiel , texfieldov atď ... ich umiestnenie v okne
		
		hlOkno.getChildren().addAll(grafSubor,grafTvorba,menu,algExistencia,algRovina,algMatica,algSuvisly,algFloydov,algDikstra
				,infExis,infRov,infMat,infSuv,infFloyd,infDiks);
		
		
		GridPane.setConstraints(grafSubor,1,1);
		GridPane.setConstraints(grafTvorba,1,2);
		
		GridPane.setConstraints(menu,1,8);

		GridPane.setConstraints(algExistencia,1,12);
		GridPane.setConstraints(algRovina,1,14);
		GridPane.setConstraints(algMatica,1,16);
		GridPane.setConstraints(algSuvisly,5,12);
		GridPane.setConstraints(algFloydov,5,14);
		GridPane.setConstraints(algDikstra,5,16);

		
		GridPane.setConstraints(infExis,2,12);
		GridPane.setConstraints(infRov,2,14);
		GridPane.setConstraints(infMat,2,16);
		GridPane.setConstraints(infSuv,6,12);
		GridPane.setConstraints(infFloyd,6,14);
		GridPane.setConstraints(infDiks,6,16);

		// rozmery tacidiel , uprava vzhladu		
		nastavenieB(algExistencia);
		nastavenieB(algRovina);
		nastavenieB(algMatica);
		nastavenieB(algSuvisly);
		nastavenieB(algFloydov);
		nastavenieB(algDikstra);
		
		
		nastavenieInf(infExis);
		nastavenieInf(infRov);
		nastavenieInf(infMat);
		nastavenieInf(infSuv);
		nastavenieInf(infFloyd);
		nastavenieInf(infDiks);
		
		// akcie pre tlacidla 
		
		grafSubor.setOnAction(e -> {
			GUISubor shSubor = new GUISubor(controller);
			
			
			});
		
		
		Scene scene = new Scene(hlOkno,800,500);
		 setScene(scene);
		 show();
		
		
	}
	
	
}
