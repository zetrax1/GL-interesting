/**
 * 
 */
package testyPrikazov;

/**
 * @author zetrax
 *
 */
public class Marec6 {
	
	
	
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
