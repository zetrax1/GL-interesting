package controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Scanner;

public class FilesTxt {

	
	private Scanner subor;
	private String pole = null;
	Writer zapis ;
	
	
	public void otvorSubor(String adresa) {
		
		try {
			subor = new Scanner(new File(adresa));
		} catch (Exception e) {
			System.out.println("subor sa nepodarilo otvorit");

		}
		
		
	}
	
	public String citajCely() {
		
		subor.reset();
		if(subor.hasNext()) {
		pole = subor.nextLine();
		}else {
			return null;
		}
		while (subor.hasNext()) {
			pole = pole + "\n" + subor.nextLine();

		}
		
		
		return pole;
	}
	
	
	public void zaciatokSuboru() {
		
		subor.reset();
	}
	
	
	
	
	
	
	public String citajSuborJedenRiadok() {
		String riadok;
		
		if(subor.hasNext()) {
		riadok = subor.nextLine();
		return riadok;
		}else{
			
			return null;
		}
		
	
	}
	
	
	public void zavriSubor() {
		subor.close();
	}
	
	
	public void zapisAdresu(String adresa)  {
		
		try {
		zapis = new FileWriter("subory.txt");
		zapis.write(adresa); // write string
		zapis.flush();
		zapis.close();
		} catch (Exception e) {
			System.out.println("Do suboru sa nepodarilo zapisat");
			
		} finally {
		//	zapis.close();
			
		}
	
		
	}
	
	
	
	
	
	
}
