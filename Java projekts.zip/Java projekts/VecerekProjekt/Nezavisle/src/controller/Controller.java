package controller;

import java.util.ArrayList;

import model.Hrana;
import model.Vrchol;
import controller.FilesTxt;

public class Controller {

	private String SUBORHISTORY = "/home/zetrax/git/PreEclipseJava/Nezavisle/src/subory.txt";

	private ArrayList<Vrchol> vrcholList;

	private int typGraf; // 0 graf , 1 digraf

	public Controller() {
		vrcholList = new ArrayList<Vrchol>();
		typGraf = 0;

	}

	public String historyFileR() {

		FilesTxt subor = new FilesTxt();
		String tmp = null;
		subor.otvorSubor(SUBORHISTORY);
		tmp = subor.citajCely();
		subor.zavriSubor();

		return tmp;
	}

	public String historyFileR(String adresa) {

		FilesTxt subor = new FilesTxt();
		String tmp = null;
		subor.otvorSubor(SUBORHISTORY);
		tmp = subor.citajCely();

		subor.zavriSubor();

		return tmp;
	}

	public void grafSubor(String adresa) {

		FilesTxt subor = new FilesTxt();

		subor.otvorSubor(adresa);

		nacitajUdajeSubor(subor);
		subor.zavriSubor();

		// subor.zapisAdresu(adresa);

	}

	private void pridajDoList(String meno) {

		vrcholList.add(new Vrchol(meno));

	}

	private void nacitajUdajeSubor(FilesTxt subor) {

		String tmp;

		tmp = subor.citajSuborJedenRiadok();
		if (tmp.equalsIgnoreCase("graf")) {
			this.typGraf = 0;
		} else {
			this.typGraf = 1;
		}

		tmp = subor.citajSuborJedenRiadok();
		tmp = subor.citajSuborJedenRiadok();

		while (!tmp.equals("Hrany:")) {

			pridajDoList(tmp);
			tmp = subor.citajSuborJedenRiadok();

		}
		tmp = subor.citajSuborJedenRiadok();

		vypisVrcholy();
		while (!tmp.equals("Poznamka")) {

			tmp = subor.citajSuborJedenRiadok();
			if (tmp == null) {
				return;
			}
		}

		return;

	}

	public int najdiIndexVrcholu(String nazov) {

		for (int i = 0; i < vrcholList.size(); i++) {
			if (nazov.split(" ").equals(vrcholList.get(i).getNazov())) {

				return i;

			}
		}

		return 0;
	}

	public void pridajHranuGraf(String tmpHrana) {

	}

	public void pridajHranuDiGraf(String tmpHrana) {

	}

	public void vypisVrcholy() {
		for (int i = 0; i < vrcholList.size(); i++) {
			System.out.print(vrcholList.get(i).getNazov() + " ");
		}
		System.out.print("   ////   ");
	}
}
