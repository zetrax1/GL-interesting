package Controler;

public class VlastnaVynimka extends Exception {

}
