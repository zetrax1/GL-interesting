package Controler;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;

import Model.Chemikalia;
import Sklady.Firma;
import Sklady.Sklad;
import Sklady.SkladStupenZabezpeceniaDva;
import Sklady.SkladStupenZabezpeceniaJedna;
import Sklady.SkladStupenZabezpeceniaPat;
import Sklady.SkladStupenZabezpeceniaStyri;
import Sklady.SkladStupenZabezpeceniaTri;
import transport.Cisterna;
import transport.Kamion;
import transport.Liaz;
import transport.Vozidlo;

public class Controller {

	private ArrayList<Sklad> storeList = new ArrayList<Sklad>();
	//private LinkedList<Chemikalia> objedChem = new LinkedList<Chemikalia>();
	private ArrayList<Vozidlo> VozidloList = new ArrayList<Vozidlo>();
	private Firma firma;
	
	public Controller() {
		storeList.add(new SkladStupenZabezpeceniaJedna());//0
		storeList.add(new SkladStupenZabezpeceniaDva());
		storeList.add(new SkladStupenZabezpeceniaTri());
		storeList.add(new SkladStupenZabezpeceniaStyri());
		storeList.add(new SkladStupenZabezpeceniaPat());
		 
		 this.firma = new Firma();
	}
	
	
	public int najdiSklad(String zabezpecenie) {
		
		Sklad sklad;
		
		for (int i = 0; i < storeList.size(); i++) {
			sklad = storeList.get(i);
			if(sklad.zabezpecenie().equals(zabezpecenie)){
				return i;
			}
		}
		//prejde v�dy
		return 0;
	}
	
	public int zistiHmotnost(String skupenstvo, String zabezpecenie){
		
		int hmotnost=0;;
		Sklad sklad;
		Chemikalia chemikalia;
		
		int pozicia;
		LinkedList<Chemikalia> pom;
		
		pozicia = najdiSklad(zabezpecenie);
		
		for (int i = 0; i < storeList.size(); i++) {
			if(i==pozicia){
				sklad=storeList.get(i);
				pom=sklad.getlist();
				
				for(int j =0; j<pom.size(); j++){
					chemikalia=pom.get(j);
					if(chemikalia.getSkupenstov().equals(skupenstvo)){
						hmotnost+=chemikalia.getHmot();
					}
				}
				return hmotnost;
			}
		}
		return 0;
	}
	
	
	public void objednajdoFirmy(int id, int hmotnost, Firma firma){
		firma.pridajDoListu(id, hmotnost);
		
	}
	
	public Firma getFirma(){
		return this.firma;
	}
	
	public boolean prehladajSklad(int id, int hmotnost, String zabezpecenie){
		
		int pom;
		pom = najdiSklad(zabezpecenie);
		Sklad sklad ;
		sklad =  storeList.get(pom);
		if(sklad.zistiId(id) && sklad.zistiHmotnosID(hmotnost, id)){
			return true;
		}
		return false;
	}
	
	public void zmazObjednavku(){
		firma.getlist().clear();
		//zmaze vsetky polozky vo firme
	}
	
	public int zistiHmotnostFirma(String skupenstvo){
		int hmotnost;
		hmotnost =firma.vratHmotnost(skupenstvo);
		return hmotnost;
		
	}
	
	public String pouziteVozidla(){
		int kam=0;
		int liaz=0;
		int cist=0;
		int tmp=0;
		int hmot=0;
		String textNaVypis;
		
		Vozidlo vozidlo = new Vozidlo();
		LinkedList<Chemikalia> ChemikList;
		
		ChemikList= firma.getlist();
		Chemikalia chemikalia;
		ZoznamCh zoznamCh =new ZoznamCh();
		
		
		for(int i=0;i<ChemikList.size();i++){
			chemikalia=ChemikList.get(i);
			boolean reaktivita = zoznamCh.citajSuborPreReaktivitu(Integer.toString(chemikalia.getID()));
			
		if(reaktivita){
			int mreaktivnych;
			int pocetVozidiel;
			switch (zoznamCh.citajSuborPreSkupenstvo(Integer.toString( chemikalia.getID()))) {
			case "kvapalne":
				
				mreaktivnych = chemikalia.getHmot();
				pocetVozidiel =mreaktivnych/5;
				for(int j=0;j<pocetVozidiel;j++){
					VozidloList.add(new Cisterna()); 
				cist++;
				}
				VozidloList.trimToSize();
				break;
			case "tuhe": 
				mreaktivnych = chemikalia.getHmot();
				pocetVozidiel=mreaktivnych/10;
				if(mreaktivnych%10>5){
					pocetVozidiel++;
				}
				for(int j=0;j<pocetVozidiel;j++){
					VozidloList.add(new Kamion()); 
					kam++;
				}
				
				if(mreaktivnych%10<5){
					VozidloList.add(new Liaz()); 
					liaz++;
				}
				
				VozidloList.trimToSize();
				break;
				
			case "plynne":
				mreaktivnych = chemikalia.getHmot();
				pocetVozidiel=mreaktivnych/10;
				if(mreaktivnych%10>5){
					pocetVozidiel++;
				}
				for(int j=0;j<pocetVozidiel;j++){
					VozidloList.add(new Kamion());
					kam++;
				}
				
				if(mreaktivnych%10<5){
					VozidloList.add(new Liaz()); 
					liaz++;
				}
				VozidloList.trimToSize();
				break;
			}
			
			
			
		}else{
			
			int pom=0;
			int zvysok;
			
			if (zoznamCh.citajSuborPreSkupenstvo(Integer.toString( chemikalia.getID())).equals("tuhe") ||zoznamCh.citajSuborPreSkupenstvo(Integer.toString( chemikalia.getID())).equals("plynne")) {
				
				hmot+=chemikalia.getHmot();
				
			} else {
				if (chemikalia.getHmot()>3) {
					pom=chemikalia.getHmot()/5;
					if (chemikalia.getHmot()%5>3) {
						pom++;
						
					}
					else {
						zvysok=chemikalia.getHmot()%5;
						hmot+=zvysok;
					}
					for(int j=0;j<pom;j++){
						VozidloList.add(new Cisterna());
						cist++;
					}
				}
			}
		}
			
			
			
		}
		
		tmp = hmot /10;
		if(hmot%10>5){
			tmp++;
		}else{
			VozidloList.add(new Liaz());
			liaz++;
		}
		
		for(int j=0;j<tmp;j++){
			VozidloList.add(new Kamion());
			kam++;
		}
		
	
		
		textNaVypis = "********** \n"+" Po�et Kamionov pou�it�ch na prepravu : "+Integer.toString(kam)+ "\n"+" Po�et Liazok pou�it�ch na prepravu : "+Integer.toString(liaz)+"\n"+" Po�et Cisterien pou�it�ch na prepravu : "+Integer.toString(cist);
				
		return textNaVypis;
	}
	
}
