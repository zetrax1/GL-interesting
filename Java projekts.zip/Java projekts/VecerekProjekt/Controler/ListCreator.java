package Controler;

import java.util.ArrayList;
import java.util.LinkedList;

import Model.Chemikalia;

public class ListCreator {

	
	//genericka metoda
	public static <T> LinkedList<T> createList(){
		return new LinkedList();
	}
}
