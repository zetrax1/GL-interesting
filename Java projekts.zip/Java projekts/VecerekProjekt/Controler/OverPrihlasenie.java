package Controler;

public class OverPrihlasenie {
	
public boolean overPrihlasenie(String meno,String heslo){
		
		if(meno.length()>0 && heslo.length()>0){
			
			return true;
		}
		else
			return false;
	 
	}
	

}
