package Controler;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import org.omg.CORBA.PRIVATE_MEMBER;


import Sklady.Sklad;
import Sklady.SkladStupenZabezpeceniaDva;
import Sklady.SkladStupenZabezpeceniaJedna;
import Sklady.SkladStupenZabezpeceniaPat;
import Sklady.SkladStupenZabezpeceniaStyri;
import Sklady.SkladStupenZabezpeceniaTri;


public class ZoznamCh {

	private Scanner subor;
	private String pole = null;

	public void otvorSubor() {
		try {
			subor = new Scanner(new File("D:\\2.semester\\oop\\eclipse\\Projekt\\src\\Chemikalie.txt"));
		} catch (Exception e) {
			System.out.println("subor sa nepodarilo otvorit");

		}

	}

	public void resetniSubor() {
		subor.reset();
		otvorSubor();
	}

	public String citajSuborPoSlovach(String hladanyNazov) {
		while (subor.hasNext()) {
			String identicikacneCislo = subor.next();
			String nazov = subor.next();
			String chemickaSkratka = subor.next();
			String reaktivita = subor.next();
			String skupenstvo = subor.next();
			int zabezpecenie = subor.nextInt();

			if (hladanyNazov.equals(nazov)) {
				return identicikacneCislo;
			}
		}
		return "Chemikalia nieje v zozname";
	}
	
	public  boolean zistiIdZoznam(String kodProduktu) throws VlastnaVynimka {
		otvorSubor();
		while (subor.hasNext()) {
			String identicikacneCislo = subor.next();
			String nazov = subor.next();
			String chemickaSkratka = subor.next();
			String reaktivita = subor.next();
			String skupenstvo = subor.next();
			int zabezbecenie = subor.nextInt();

			if (kodProduktu.equals(identicikacneCislo) ) {
				zavriSubor();
				return true;
				
			}
		}
		zavriSubor();
		throw new VlastnaVynimka();
	}
	
	

	public  boolean citajSuborPreReaktivitu(String kodProduktu) {
		otvorSubor();
		while (subor.hasNext()) {
			String identicikacneCislo = subor.next();
			String nazov = subor.next();
			String chemickaSkratka = subor.next();
			String reaktivita = subor.next();
			String skupenstvo = subor.next();
			int zabezbecenie = subor.nextInt();

			if (kodProduktu.equals(identicikacneCislo) && reaktivita.equals("reaktivny")) {
				zavriSubor();
				return true;
			}
		}
		zavriSubor();
		return false;
		
	}

	public String citajSuborPreSkupenstvo(String kodProduktu) {
		otvorSubor();
		while (subor.hasNext()) {
			String identicikacneCislo = subor.next();
			String nazov = subor.next();
			String chemickaSkratka = subor.next();
			String reaktivita = subor.next();
			String skupenstvo = subor.next();
			int zabezbecenie = subor.nextInt();

			if (kodProduktu.equals(identicikacneCislo)) {
				zavriSubor();
				return skupenstvo;
			}
		}
		zavriSubor();
		return kodProduktu;

	}

	public int citajSuborPreStupen(String kodProduktu) {
		while (subor.hasNext()) {
			String identicikacneCislo = subor.next();
			String nazov = subor.next();
			String chemickaSkratka = subor.next();
			String reaktivita = subor.next();
			String skupenstvo = subor.next();
			int zabezbecenie = subor.nextInt();

			if (kodProduktu.equals(identicikacneCislo)) {
				return zabezbecenie;
			}
		}

		return 0;

	}

	public String citajSuborJedenRiadok() {
		String riadok;
		riadok = subor.nextLine();

		return riadok;

	}

	public String citajSuborCely() {

		subor.reset();
		pole = subor.nextLine();

		while (subor.hasNext()) {
			pole = pole + "\n" + subor.nextLine();

		}

		return pole;
	}


	public void zavriSubor() {
		subor.close();
	}

}
