package transport;

public interface Nosnost {

	void nastavNosnost(int num);
}
