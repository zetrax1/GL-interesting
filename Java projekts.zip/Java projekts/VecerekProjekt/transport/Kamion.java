package transport;

public class Kamion extends Vozidlo implements Nosnost {
	
	
	public Kamion() {
		this.nosnost=10;
	}

	@Override
	public void nastavNosnost(int num) {
		this.nosnost=num;
	}
	
}
