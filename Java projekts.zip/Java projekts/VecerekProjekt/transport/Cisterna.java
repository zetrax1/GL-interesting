package transport;

public class Cisterna extends Vozidlo implements Nosnost{

	
	public Cisterna() {
	this.nosnost = 5;
}

	@Override
	public void nastavNosnost(int num) {
		this.nosnost=num;
		
	}
}
