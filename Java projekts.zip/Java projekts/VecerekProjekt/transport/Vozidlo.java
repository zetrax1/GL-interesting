package transport;

import java.util.ArrayList;
import java.util.LinkedList;

import Model.Chemikalia;

public class Vozidlo {

	protected int nosnost;  //ton
	protected LinkedList<Chemikalia> ChemListVozidlo;
	
	
	public int getNosnost(){
		return this.nosnost;
	}
	
	
	
	
	
	
}
