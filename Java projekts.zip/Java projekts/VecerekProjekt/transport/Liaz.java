package transport;

public class Liaz extends Vozidlo{

	public Liaz() {
		this.nosnost=5;
	}
}
