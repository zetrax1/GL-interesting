package Sklady;

import java.util.LinkedList;

import Controler.ListCreator;
import Controler.ZoznamCh;
import Model.Chemikalia;

public class Firma extends Sklad{
	
	public Firma() {
		this.zabezpecenie=null; // nema zabezpe�enie
		this.Chemlist=ListCreator.createList();
		
	}
	
	public void pridajDoListu(int id, int hmotnost){
		this.Chemlist.add(new Chemikalia(id, hmotnost));
	}
	

 	
	//prehladavanie suboru
	
	public String zistiInfo(){
		String pom="";
		int num=0;
		
		Chemikalia chemikalia;
		
		for(int i=0;i<Chemlist.size();i++){
			chemikalia=Chemlist.get(i);
			num++;
			pom +="*******\n" + Integer.toString(num) + ":ID " +chemikalia.getID() + " Hmotnos� " + chemikalia.getHmot() + "\n";
			
		}
		return pom;
	}
	
	public int vratHmotnost(String skupenstvo){
		
		int hmotnost=0;
		Chemikalia chemikalia;
		ZoznamCh zoznamCh = new ZoznamCh();
		
		for(int i=0;i<Chemlist.size();i++){
			chemikalia=Chemlist.get(i);
			if(zoznamCh.citajSuborPreSkupenstvo(Integer.toString(chemikalia.getID())).equals(skupenstvo)){
				hmotnost +=chemikalia.getHmot();
				
			}
			
				
		}
		return hmotnost;
		
	}
	



}
