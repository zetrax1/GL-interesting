package Sklady;

import java.util.ArrayList;
import java.util.LinkedList;

import Model.Chemikalia;
import javafx.fxml.Initializable;

public abstract class Sklad {
	
	protected final int kapacita=100; //ton
	protected LinkedList<Chemikalia> Chemlist;
	protected  String zabezpecenie;
	
	/*
	public boolean najdiChemikaliu(int id){
		
	
	}*/
	
	//zisti aktualny pocet chemikalii v danom sklade
	public int zistiPocetChem(){
		return this.Chemlist.size();
	}
	
	public int zistiHmotnost(String skupenstvo){
		
		int hmotnost=0;
		Chemikalia chemikalia;
		
		if(!Chemlist.isEmpty()){
			
			for(int i= 0; i<Chemlist.size();i++ ){
				chemikalia=Chemlist.get(i);
				if(chemikalia.getSkupenstov().equals(skupenstvo)){
					hmotnost+=chemikalia.getHmot();
				}
			}
			return hmotnost;	
		}
			else {
				return 0;
			}
	}
	
	public String zabezpecenie(){
		return this.zabezpecenie;
	}
	
	public LinkedList<Chemikalia> getlist(){
		return this.Chemlist;
	}
	
	public boolean zistiId(int id){
		Chemikalia chemikalia;
		
		for(int i=0; i<Chemlist.size();i++){
			chemikalia=Chemlist.get(i);
			if(chemikalia.getID()==id){
				return true;
			}
		}
		return false;
	}
	
	public boolean zistiHmotnosID(int hmotnost, int id){
		Chemikalia chemikalia;
		
		for(int i=0;i<Chemlist.size();i++){
			chemikalia=Chemlist.get(i);
			
			if(chemikalia.getID()==id && chemikalia.getHmot()>=hmotnost){
				return true;
			}
		}
		return false;
	}
	
}


