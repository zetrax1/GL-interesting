package all;

import java.util.ArrayList;

public class Jedinec {


	public ArrayList<Gen> geny = new ArrayList<Gen>();
	public int pocetPolicok;
	
	
	public Jedinec() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
